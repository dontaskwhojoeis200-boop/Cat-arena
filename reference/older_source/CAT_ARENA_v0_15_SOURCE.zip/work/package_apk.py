from pathlib import Path
import struct as st,zipfile,hashlib,datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
U32=lambda x:st.pack('<I',x)
U64=lambda x:st.pack('<Q',x)
LP=lambda b:U32(len(b))+b
base=Path('work');out=Path('output');out.mkdir(exist_ok=True)
# Rebuild the binary XML string pool, preserving the existing native wrapper and permissions.
b=bytearray((base/'AndroidManifest.xml').read_bytes());p=8;typ,hs,size=st.unpack_from('<HHI',b,p);assert typ==1
n,styles,flags,start,sty=st.unpack_from('<5I',b,p+8);assert flags&256 and not styles
strings=[]
for i in range(n):
 off=st.unpack_from('<I',b,p+hs+4*i)[0];q=p+start+off
 def length(q):
  v=b[q];return (((v&127)<<8)|b[q+1],q+2) if v&128 else (v,q+1)
 _,q=length(q);ln,q=length(q);strings.append(bytes(b[q:q+ln]).decode())
strings=[{'com.voidarena.bastion':'com.voidarena.helios','VOID ARENA':'CAT ARENA','0.11':'0.15'}.get(s,s) for s in strings]
def l8(n):return bytes([n]) if n<128 else bytes([(n>>8)|128,n&255])
data=b'';offset=[]
for s in strings:
 offset.append(len(data));bb=s.encode();data+=l8(len(s.encode('utf-16-le'))//2)+l8(len(bb))+bb+b'\0'
data+=b'\0'*((-len(data))%4);sp=st.pack('<HHI5I',1,28,28+4*n+len(data),n,0,256,28+4*n,0)+b''.join(U32(o) for o in offset)+data
manifest=bytearray(b[:8]+sp+b[p+size:]);st.pack_into('<I',manifest,4,len(manifest))
p=8
while p<len(manifest):
 typ,hs,sz=st.unpack_from('<HHI',manifest,p)
 if typ==0x102:
  count=st.unpack_from('<H',manifest,p+28)[0]
  for i in range(count):
   q=p+36+i*20;name=st.unpack_from('<I',manifest,q+4)[0]
   if strings[name]=='versionCode':st.pack_into('<I',manifest,q+16,15)
 p+=sz
(base/'HeliosManifest.xml').write_bytes(manifest)
keypath=base/'helios-signing-key.pem'
if not keypath.exists():
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 keypath.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
else:key=serialization.load_pem_private_key(keypath.read_bytes(),None)
name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'VOID ARENA Helios Development')])
cert=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(12).not_valid_before(datetime.datetime(2026,1,1)).not_valid_after(datetime.datetime(2056,1,1)).sign(key,hashes.SHA256())
certder=cert.public_bytes(serialization.Encoding.DER);(base/'helios-signing-cert.der').write_bytes(certder)
unsigned=base/'unsigned.apk'
with zipfile.ZipFile(unsigned,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for fn,data in [('AndroidManifest.xml',manifest),('classes.dex',(base/'classes.dex').read_bytes()),('assets/index.html',(base/'assets/index.html').read_bytes())]:
  zi=zipfile.ZipInfo(fn,(2026,11,8,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;z.writestr(zi,data)
b=unsigned.read_bytes();eo=b.rfind(b'PK\x05\x06');assert eo+22==len(b);co=st.unpack_from('<I',b,eo+16)[0]
# APK Signature Scheme v2 content digest, independently chunked across all three signed sections.
chunkdig=[]
for sec in [b[:co],b[co:eo],b[eo:]]:
 for i in range(0,len(sec),1024*1024):
  c=sec[i:i+1024*1024];chunkdig.append(hashlib.sha256(b'\xa5'+U32(len(c))+c).digest())
digest=hashlib.sha256(b'\x5a'+U32(len(chunkdig))+b''.join(chunkdig)).digest();alg=0x0103
signed=LP(LP(U32(alg)+LP(digest)))+LP(LP(certder))+LP(b'')
sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
signer=LP(signed)+LP(LP(U32(alg)+LP(sig)))+LP(pub)
value=LP(LP(signer));pair=U64(4+len(value))+U32(0x7109871a)+value
size=len(pair)+24;block=U64(size)+pair+U64(size)+b'APK Sig Block 42'
eocd=bytearray(b[eo:]);st.pack_into('<I',eocd,16,co+len(block))
apk=out/'CAT_ARENA_v0_15_GRAPHICS_FIXED.apk';apk.write_bytes(b[:co]+block+b[co:eo]+eocd)
print('APK',apk,'bytes',apk.stat().st_size,'sha256',hashlib.sha256(apk.read_bytes()).hexdigest())
print('Package com.voidarena.helios; version 15 / 0.15; target SDK unchanged (36); activity unchanged.')
