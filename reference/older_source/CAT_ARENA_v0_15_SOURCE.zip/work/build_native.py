"""Minimal native Android WebView wrapper, assembled as DEX 035.
Retains the activity name and package compatibility, adds real Exit and Back.
No external Android SDK dependency.
"""
import struct as S, hashlib,zlib
from pathlib import Path
U=lambda n:S.pack('<I',n)
H=lambda n:S.pack('<H',n)
def leb(n):
 b=bytearray()
 while n>127:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)
A='Landroid/app/Activity;'; M='Lcom/voidarena/bastion/MainActivity;'
C='Lcom/voidarena/bastion/CatChrome;'; W='Landroid/webkit/WebView;'
WC='Landroid/webkit/WebChromeClient;'; WS='Landroid/webkit/WebSettings;'
V='Landroid/view/View;'; WIN='Landroid/view/Window;'; B='Landroid/os/Bundle;'
STR='Ljava/lang/String;'; CTX='Landroid/content/Context;'; CLIENT='Landroid/webkit/WebViewClient;'; JR='Landroid/webkit/JsResult;'
methods=[];fields=[(M,'web',W),(C,'owner',A)]
def method(c,n,r='V',args=()):
 k=(c,n,r,tuple(args))
 if k not in methods:methods.append(k)
 return k
# All refs before indexing.
initA=method(A,'<init>');initM=method(M,'<init>')
createA=method(A,'onCreate',args=[B]);createM=method(M,'onCreate',args=[B])
focusA=method(A,'onWindowFocusChanged',args=['Z']);focusM=method(M,'onWindowFocusChanged',args=['Z'])
backM=method(M,'onBackPressed')
getwin=method(A,'getWindow',WIN);getdecor=method(WIN,'getDecorView',V)
flags=method(WIN,'setFlags',args=['I','I']);ui=method(V,'setSystemUiVisibility',args=['I'])
orient=method(A,'setRequestedOrientation',args=['I']);content=method(A,'setContentView',args=[V])
initW=method(W,'<init>',args=[CTX]);getsettings=method(W,'getSettings',WS)
js=method(WS,'setJavaScriptEnabled',args=['Z']);dom=method(WS,'setDomStorageEnabled',args=['Z'])
access=method(WS,'setAllowFileAccess',args=['Z']);media=method(WS,'setMediaPlaybackRequiresUserGesture',args=['Z'])
wc=method(W,'setWebChromeClient',args=[WC]);client=method(W,'setWebViewClient',args=[CLIENT]);url=method(W,'loadUrl',args=[STR])
initClient=method(CLIENT,'<init>');initWC=method(WC,'<init>');initC=method(C,'<init>',args=[A])
confirmC=method(C,'onJsConfirm','Z',[W,STR,STR,JR]);confirm=method(JR,'confirm')
finish=method(A,'finishAndRemoveTask')
destroyM=method(M,'onDestroy');destroyA=method(A,'onDestroy');destroyW=method(W,'destroy')
strings={'file:///android_asset/index.html','javascript:window.catBack&&catBack()'}
types={M,C,A,'V','Z','I'}
protos=set()
def short(t):return 'L' if t[0] in 'L[' else t
for c,n,r,args in methods:
 strings.add(n);types.update([c,r,*args]);protos.add((r,args));strings.add(short(r)+''.join(map(short,args)))
for c,n,t in fields:strings.add(n);types.update([c,t])
strings.update(types);strings=sorted(strings);si={s:i for i,s in enumerate(strings)}
types=sorted(types,key=si.get);ti={t:i for i,t in enumerate(types)}
protos=sorted(protos,key=lambda p:(ti[p[0]],tuple(ti[t] for t in p[1])));pi={p:i for i,p in enumerate(protos)}
methods.sort(key=lambda m:(ti[m[0]],si[m[1]],pi[(m[2],m[3])]))
mi={m:i for i,m in enumerate(methods)}
fields.sort(key=lambda f:(ti[f[0]],si[f[1]],ti[f[2]]));fi={f:i for i,f in enumerate(fields)}
def inv(op,m,*regs):
 assert len(regs)<=5 and all(r<16 for r in regs)
 rs=list(regs)+[0]*5
 return [op|(len(regs)<<12)|(rs[4]<<8),mi[m],rs[0]|rs[1]<<4|rs[2]<<8|rs[3]<<12]
def const(r,n):return [0x13|(r<<8),n&65535]
def new(r,t):return [0x22|(r<<8),ti[t]]
def result(r):return [0x0c|(r<<8)]
def string(r,s):return [0x1a|(r<<8),si[s]]
def field(op,a,b,f):return [op|a<<8|b<<12,fi[f]]
ret=[0x0e]
codes={}
def define(m,regs,ins,outs,code,flags=1):codes[m]=(regs,ins,outs,code,flags)
define(initM,1,1,1,inv(0x70,initA,0)+ret,0x10001)
# 8 regs: v6=this, v7=bundle
code=inv(0x6f,createA,6,7)+const(0,0)+inv(0x6e,orient,6,0)
code+=inv(0x6e,getwin,6)+result(0)+const(1,1024)+inv(0x6e,flags,0,1,1)
code+=inv(0x6e,getdecor,0)+result(0)+const(1,5894)+inv(0x6e,ui,0,1)
code+=new(0,W)+inv(0x70,initW,0,6)+field(0x5b,0,6,(M,'web',W))
code+=inv(0x6e,getsettings,0)+result(1)+const(2,1)
for m in [js,dom,access]:code+=inv(0x6e,m,1,2)
code+=const(2,0)+inv(0x6e,media,1,2)
code+=new(1,C)+inv(0x70,initC,1,6)+inv(0x6e,wc,0,1)
code+=new(1,CLIENT)+inv(0x70,initClient,1)+inv(0x6e,client,0,1)
code+=inv(0x6e,content,6,0)+string(1,'file:///android_asset/index.html')+inv(0x6e,url,0,1)+ret
define(createM,8,2,3,code,4)
define(focusM,4,2,2,inv(0x6f,focusA,2,3)+inv(0x6e,getwin,2)+result(0)+inv(0x6e,getdecor,0)+result(0)+const(1,5894)+inv(0x6e,ui,0,1)+ret)
define(backM,3,1,2,field(0x54,0,2,(M,'web',W))+string(1,'javascript:window.catBack&&catBack()')+inv(0x6e,url,0,1)+ret)
define(destroyM,2,1,1,field(0x54,0,1,(M,'web',W))+inv(0x6e,destroyW,0)+inv(0x6f,destroyA,1)+ret,4)
define(initC,2,2,1,inv(0x70,initWC,0)+field(0x5b,1,0,(C,'owner',A))+ret,0x10001)
# v1=this, v2=web, v3=url, v4=message, v5=result. Only app Exit uses confirm().
define(confirmC,6,5,1,inv(0x6e,confirm,5)+field(0x54,0,1,(C,'owner',A))+inv(0x6e,finish,0)+const(0,1)+[0x0f])
classes=sorted([M,C],key=ti.get)
header=112
so=header;to=so+4*len(strings);po=to+4*len(types);fo=po+12*len(protos);mo=fo+8*len(fields);co=mo+8*len(methods);do=co+32*len(classes)
data=bytearray();sections=[]
def align():
 while (do+len(data))%4:data.append(0)
def put(b):o=do+len(data);data.extend(b);return o
stringoffs=[]
start=do+len(data)
for s in strings:stringoffs.append(put(leb(len(s))+s.encode()+b'\0'))
sections.append((0x2002,len(strings),start))
typeoffs={};start=None
for r,args in protos:
 if args and args not in typeoffs:
  align();off=put(U(len(args))+b''.join(H(ti[x]) for x in args));typeoffs[args]=off
  if start is None:start=off
if start is not None:sections.append((0x1001,len(typeoffs),start))
codeoffs={};start=None
for m in sorted(codes,key=mi.get):
 align();regs,ins,outs,code,fl=codes[m]
 off=put(S.pack('<4H2I',regs,ins,outs,0,0,len(code))+b''.join(H(x) for x in code));codeoffs[m]=off
 if start is None:start=off
sections.append((0x2001,len(codeoffs),start))
classdata={};start=None
for c in classes:
 fs=[f for f in fields if f[0]==c]
 direct=sorted([m for m in codes if m[0]==c and m[1]=='<init>'],key=mi.get)
 virtual=sorted([m for m in codes if m[0]==c and m[1]!='<init>'],key=mi.get)
 b=leb(0)+leb(len(fs))+leb(len(direct))+leb(len(virtual));prev=0
 for f in fs:b+=leb(fi[f]-prev)+leb(1);prev=fi[f]
 for group in [direct,virtual]:
  prev=0
  for m in group:b+=leb(mi[m]-prev)+leb(codes[m][4])+leb(codeoffs[m]);prev=mi[m]
 off=put(b);classdata[c]=off
 if start is None:start=off
sections.append((0x2000,len(classes),start))
align();mapoff=do+len(data)
maps=[(0,1,0),(1,len(strings),so),(2,len(types),to),(3,len(protos),po),(4,len(fields),fo),(5,len(methods),mo),(6,len(classes),co),*sections,(0x1000,1,mapoff)]
maps.sort(key=lambda x:x[2]);put(U(len(maps))+b''.join(S.pack('<HHII',t,0,n,o) for t,n,o in maps))
out=bytearray(112)
out+=b''.join(U(x) for x in stringoffs)+b''.join(U(si[t]) for t in types)
for r,args in protos:out+=U(si[short(r)+''.join(map(short,args))])+U(ti[r])+U(typeoffs.get(args,0))
for c,n,t in fields:out+=H(ti[c])+H(ti[t])+U(si[n])
for c,n,r,args in methods:out+=H(ti[c])+H(pi[(r,args)])+U(si[n])
for c in classes:out+=S.pack('<8I',ti[c],1,ti[A if c==M else WC],0,0xffffffff,0,classdata[c],0)
assert len(out)==do
out+=data
out[:8]=b'dex\n035\0'
S.pack_into('<20I',out,32,len(out),112,0x12345678,0,0,mapoff,len(strings),so,len(types),to,len(protos),po,len(fields),fo,len(methods),mo,len(classes),co,len(data),do)
out[12:32]=hashlib.sha1(out[32:]).digest();S.pack_into('<I',out,8,zlib.adler32(out[12:])&0xffffffff)
Path('work/classes.dex').write_bytes(out)
print('Native wrapper:',len(out),'bytes;',len(methods),'methods;',len(classes),'classes')
