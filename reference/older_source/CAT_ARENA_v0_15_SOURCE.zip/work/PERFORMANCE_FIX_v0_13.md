# Helios performance fix v0.13

The attached v0.12 APK was byte-identical to the delivered build.

## Confirmed defects and fixes

1. Visibility bake ordering mismatch. Offline code resolved materials in first-use order. Runtime resolves all materials in registration order before mesh building. This changed the ordered visibility targets: v0.12 shipped hash `846f2402-645`, actual normal-detail runtime hash `a380df5a-645`. The stale shipped data caused fallback computation on the gameplay thread. A reproduced computation traced 21,555,260 rays and took about 18.6 seconds on this container's CPU; this is NOT a phone timing.
   Fixed the offline initialization order and embedded the matching PVS. Executing the runtime loader now reports `ready`, `source: shipped`, and zero bake rays. Helios never starts a gameplay-thread fallback visibility bake if settings change its hash. Existing frustum culling remains active in that case.
2. Repeated static material setup. Each visible cluster reuploaded material, camera, lighting and transform uniforms. Opaque clusters are now grouped per material, with contiguous visible index ranges coalesced. Transparent and portal ordering, debug isolation and uncollapsed passes retain the previous path.
3. Hidden monitor updates. A monitor could render a second scene while hidden behind an opaque wall. Its feed now checks a sight line before updating; the last image is retained, and the monitor refreshes when visible. Resolution and configured refresh rate are unchanged.

## Instrumented renderer comparison

These are actual renderer command counts recorded with a mocked GL backend, not GPU or Android benchmarks.

| Visibility sample | Old draws | New draws | Old uniform calls | New uniform calls |
|---|---:|---:|---:|---:|
| All opaque clusters | 364 | 26 | 15,652 | 1,118 |
| Alternate clusters | 182 | 182 | 7,826 | 1,075 |
| Two out of three clusters | 243 | 129 | 10,449 | 1,118 |
| Sample camera frustum | 261 | 35 | 11,223 | 1,118 |

For all four samples, expanded geometry ranges and uniform values match exactly before and after. No map geometry, textures, collision, navigation, resolution defaults or shader quality settings were reduced. JavaScript parsing, ZIP CRC, APK v2 signature/content digests, and unchanged native activity verified. Same package and identical certificate as v0.12 allow an in-place Android update.

Android device FPS and GPU timing remain unmeasured. The reported 10 FPS cannot be apportioned definitively without device profiling; the confirmed background bake and renderer setup overhead are credible contributors.
