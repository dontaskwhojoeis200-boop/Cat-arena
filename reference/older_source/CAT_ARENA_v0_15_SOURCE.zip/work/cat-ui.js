/* Original Cat Arena presentation and explicit menu routing. */
(()=>{
 const el=id=>document.getElementById(id);
 const crest='<svg class="cat-crest" viewBox="0 0 300 320" aria-label="Cat Arena feline crest" role="img"><g fill="none" stroke="currentColor"><path d="M150 8L279 85V229L150 310 21 229V85Z" stroke-width="2"/><path d="M150 23L266 93V221L150 293 34 221V93Z" opacity=".35"/><path d="M150 40V278M49 101L251 221M49 221L251 101" opacity=".16"/><path d="M76 91L113 126 150 116 187 126 224 91 215 187 190 223 150 251 110 223 85 187Z" fill="#211b20" stroke-width="3"/><path d="M86 112L111 142 97 162M214 112L189 142 203 162M102 173L137 184 119 190ZM198 173L163 184 181 190Z" fill="#ac8d55" stroke-width="2"/><path d="M143 205L150 212 157 205ZM150 212V228M150 228L134 220M150 228L166 220M122 208L67 199M121 216L65 219M178 208L233 199M179 216L235 219" stroke-width="2"/><path d="M137 65L132 97M151 60L146 94M165 65L160 97" stroke-width="4"/><path d="M48 52L61 63M252 52L239 63M45 264L59 253M255 264L241 253" stroke-width="2"/></g></svg>';
 const menu=el('menu'), oldCoop=el('coopMenu'), oldStart=el('start'), mapSelect=el('mapSelect');
 const fov=el('menuFov').closest('.menu-fov');
 fov.hidden=true;
 menu.replaceChildren();
 menu.insertAdjacentHTML('beforeend',`<header class="cat-top"><div class="cat-wordmark">CAT ARENA</div><div class="cat-edition">THE FERAL ORDER<br>VOL. XV · IRON & BLOOD</div></header>
 <section id="catHome" class="cat-home"><div><div class="cat-kicker">NINE LIVES. NO MERCY.</div><h1>CAT<span>ARENA</span></h1><nav class="cat-nav" aria-label="Main menu"><button id="catPlay" class="cat-primary">PLAY <span>01</span></button><button id="catMultiplayer">MULTIPLAYER <span>02</span></button><button id="catSettings">SETTINGS <span>03</span></button><button id="catExit">EXIT <span>04</span></button></nav></div><div class="cat-home-art">${crest}<div class="cat-motto">“Steel claws. Unbroken souls.”</div></div></section>
 <section id="catMaps" hidden><div class="cat-page-head"><h2 id="catMapsTitle">Choose your arena</h2><button class="cat-back" data-back>← BACK</button></div><div class="cat-map-layout"><div><div class="cat-map-options" id="catMapOptions"></div><div id="catMapAction"></div></div><div><figure class="cat-preview"><img id="catMapImage" hidden alt=""><div id="catPreviewStatus">PREPARING MAP VIEW…</div><figcaption id="catPreviewCaption"></figcaption></figure><div class="cat-meta"><span>IN-GAME CAPTURE</span><span id="catMapTag"></span></div><p id="catMapDescription"></p></div></div></section>
 <section id="catMulti" hidden><div class="cat-page-head"><h2>Gather the clowder</h2><button class="cat-back" data-back>← BACK</button></div><p>Stand together. Survive together. Up to four players.</p><div class="cat-nav"><button id="catHostChoice" class="cat-primary">HOST A SERVER <span>CREATE</span></button><button id="catJoinChoice">JOIN A SERVER <span>BROWSE</span></button></div></section>
 <section id="catServers" hidden><div class="cat-page-head"><h2>Available servers</h2><button class="cat-back" data-back>← BACK</button></div></section>
 <div id="catCoopDock" hidden></div><footer class="cat-footer"><span>✦ THE FERAL ORDER</span><span>CAT ARENA · 0.15</span></footer>`);
 menu.append(fov);mapSelect.hidden=true;menu.append(mapSelect);
 el('catCoopDock').append(oldCoop);
 el('catMapAction').append(oldStart);oldStart.textContent='ENTER ARENA →';
 oldCoop.querySelectorAll('h2,p').forEach(e=>e.remove());
 // Keep the engine's live form elements and handlers; move them between pages.
 const fields=oldCoop.querySelector('.coopFields'), hostName=el('coopServerName').parentElement;
 const host=el('coopHost'), refresh=el('coopRefresh');
 el('voidPauseChangeMap').insertAdjacentHTML('afterend','<button type="button" id="catReturnMenu">RETURN TO MAIN MENU</button>');
 el('voidPauseChangeMap').textContent='CHOOSE ANOTHER MAP';
 const desc={
 'helios-crucible':['Three levels · Live reactor','A burning heart of iron. Cross the gantries above the crucible and descend into its coolant halls.'],
 'bastion-keep':['Three levels · Fortress','A broken military stronghold. Fight through fortified chambers, bridges and the shattered upper keep.'],
 'reactor-bastion':['Industrial · Survival','The original reactor fortress. Interconnected decks, hard cover and close-quarters routes.'],
 'q3-gallery':['Exhibition · Combat lab','The Arsenal: an arena of experimental materials, machinery and combat spaces.']};
 const shots={
 'helios-crucible':[78,42,0,2.45,.15],
 'bastion-keep':[78,38,0,2.36,.1],
 'reactor-bastion':[78.5,60.5,0,3.14,.05],
 'q3-gallery':[42,46,0,.73,.12]};
 let route='home',mode='solo',previewPromise=null,previewURL=null,leaving=false;
 const saved=key=>{try{return localStorage.getItem(key)||''}catch{return ''}};
 const save=(key,val)=>{try{localStorage.setItem(key,val)}catch{}};
 el('coopServerUrl').value=saved('cat.relay')||el('coopServerUrl').value;
 el('coopUsername').value=saved('cat.name')||'Marine Cat';
 el('coopServerName').value=saved('cat.serverName');
 for(const [id,key] of [['coopServerUrl','cat.relay'],['coopUsername','cat.name'],['coopServerName','cat.serverName']])el(id).addEventListener('input',()=>save(key,el(id).value));
 function persistForms(){for(const [id,key] of [['coopServerUrl','cat.relay'],['coopUsername','cat.name'],['coopServerName','cat.serverName']])save(key,el(id).value);}
 function switchMap(id,target,join=''){
   persistForms();save('voidArena.map',id);
   const u=new URL(location.href);u.searchParams.set('map',id);u.searchParams.set('catPage',target);u.searchParams.delete('catJoin');
   if(join)u.searchParams.set('catJoin',join);
   location.replace(u.href);
 }
 function page(name){
   route=name;
   for(const [id,value] of [['catHome','home'],['catMaps','maps'],['catMulti','multi'],['catServers','servers']])el(id).hidden=name!==value;
   el('catCoopDock').hidden=!(['maps','servers'].includes(name));
   if(name==='maps'){
     el('catMapsTitle').textContent=mode==='host'?'Host · Choose your arena':'Choose your arena';
     oldStart.hidden=mode!=='solo';
     el('catCoopDock').hidden=mode!=='host';
     host.hidden=mode!=='host';refresh.hidden=true;hostName.hidden=false;
     el('serverList').hidden=true;el('serverBrowserStatus').hidden=true;
     if(mode==='host')el('catMaps').append(el('catCoopDock'));
     preview();
   }else if(name==='servers'){
     el('catServers').append(el('catCoopDock'));host.hidden=true;refresh.hidden=false;hostName.hidden=true;
     el('serverList').hidden=false;el('serverBrowserStatus').hidden=false;
     netBrowseServers();
   }
   el('overlay').style.display='flex';
   menu.scrollTop=0;
 }
 async function preview(){
   if(previewURL){el('catMapImage').src=previewURL;el('catMapImage').hidden=false;el('catPreviewStatus').hidden=true;return}
   if(previewPromise)return previewPromise;
   el('catPreviewStatus').hidden=false;el('catPreviewStatus').textContent='PREPARING MAP VIEW…';
   oldStart.disabled=true;host.disabled=true;
   previewPromise=(async()=>{
     try{
       await new Promise(r=>requestAnimationFrame(()=>setTimeout(r,30)));
       if(!player){
         // Map screenshots use the actual renderer and must finish installing
         // kit images/shaders before their first bake, just like normal play.
         // Otherwise the preview silently bakes a map with missing materials.
         if(typeof KIT!=='undefined'&&KIT.available&&!KIT.info.ready)await KIT.prepare();
         loadMap(0);
       }
       const original={...player},oldBots=bots,hiddenFP=window.__SHOWCASE_HIDE_FP;
       const p=shots[window.VOID_ACTIVE_MAP];
       try{
         Object.assign(player,{x:p[0],y:p[1],z:p[2],a:p[3],pitch:p[4],vx:0,vy:0,vz:0});
         bots=[];window.__SHOWCASE_HIDE_FP=true;q3Reset();render();
         // Copy synchronously from the actual WebGL backbuffer before it clears.
         const shot=document.createElement('canvas');shot.width=640;shot.height=360;
         shot.getContext('2d').drawImage(canvas,0,0,640,360);previewURL=shot.toDataURL('image/jpeg',.84);
       }finally{Object.assign(player,original);bots=oldBots;window.__SHOWCASE_HIDE_FP=hiddenFP;q3Reset();}
       el('catMapImage').src=previewURL;el('catMapImage').hidden=false;el('catPreviewStatus').hidden=true;
     }catch(e){el('catPreviewStatus').textContent='MAP VIEW UNAVAILABLE — YOU CAN STILL PLAY';console.warn('Map preview',e)}
     finally{oldStart.disabled=false;host.disabled=false;previewPromise=null}
   })();return previewPromise;
 }
 for(const [id,m] of Object.entries(window.VOID_MAPS)){
   const b=document.createElement('button');b.className=id===window.VOID_ACTIVE_MAP?'selected':'';
   b.setAttribute('aria-pressed',String(id===window.VOID_ACTIVE_MAP));
   b.textContent=m.title;const small=document.createElement('small');small.textContent=desc[id][0];b.append(small);
   b.onclick=()=>{if(id!==window.VOID_ACTIVE_MAP)switchMap(id,mode==='host'?'host':'play')};
   el('catMapOptions').append(b);
 }
 el('catPreviewCaption').textContent=window.VOID_MAPS[window.VOID_ACTIVE_MAP].title;
 el('catMapTag').textContent=desc[window.VOID_ACTIVE_MAP][0];
 el('catMapDescription').textContent=desc[window.VOID_ACTIVE_MAP][1];
 el('catPlay').onclick=()=>{mode='solo';page('maps')};
 el('catMultiplayer').onclick=()=>page('multi');
 el('catHostChoice').onclick=()=>{mode='host';page('maps')};
 el('catJoinChoice').onclick=()=>page('servers');
 document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>page(route==='servers'||(route==='maps'&&mode==='host')?'multi':'home'));
 el('catSettings').onclick=()=>{document.body.classList.add('cat-home-settings');showFovPanel(true);settingsTab('gfx');el('settingsResume').textContent='BACK TO MAIN MENU';el('voidSettingsBack').hidden=true};
 el('settingsResume').addEventListener('click',e=>{
   if(!active){e.preventDefault();e.stopImmediatePropagation();showFovPanel(false);document.body.classList.remove('cat-home-settings');page('home')}
 },true);
 function returnMenu(){
   leaving=true;active=false;loadingInProgress=false;loadingEnterAction=null;resetTouchInput();keys={};fireHeld=false;
   const sock=netSocket;netSocket=null;if(sock){sock.onclose=sock.onmessage=sock.onerror=sock.onopen=null;try{sock.close()}catch{}}
   netMode='solo';netConnecting=false;netPlayers.clear();netClients.clear();netRoom='';netPeerId='';netSelfId='';netSlot=0;
   netReviveTarget='';netReviveHolder='';netReviveSeconds=0;loadingNetRelayQueue.length=0;netSetBadge();
   if(typeof themeElement!=='undefined'&&themeElement)themeElement.pause();
   if(document.pointerLockElement)document.exitPointerLock?.();
   voidPauseOpen=false;voidSettingsFromPause=false;PAUSE.hidden=true;showFovPanel(false);
   document.body.classList.remove('void-paused','void-game-running','cat-home-settings');
   el('roomPanel').classList.remove('open');el('coopReviveStatus').style.display='none';el('coopReviveButton').style.display='none';el('deathNotice').style.display='none';
   el('settingsResume').textContent='RESUME GAME';
   page('home');leaving=false;
 }
 el('catReturnMenu').onclick=returnMenu;
 el('voidPauseChangeMap').addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();returnMenu();mode='solo';page('maps')},true);
 // Map-aware joins preserve protocol identifiers, while all visible names are Cat Arena.
 window.catJoinServer=(entry)=>{
   const match=Object.entries(window.VOID_MAPS).find(([id,m])=>m.id===entry.mapId);
   if(match&&match[0]!==window.VOID_ACTIVE_MAP){switchMap(match[0],'join',entry.id);return}
   audiostart();netConnect('join',entry.id);
 };
 const originalBegin=beginLoadedGameplay;
 beginLoadedGameplay=function(...args){document.body.classList.remove('cat-home-settings');el('settingsResume').textContent='RESUME GAME';originalBegin.apply(this,args)};
 document.body.insertAdjacentHTML('beforeend','<div id="catExitDialog" hidden role="dialog" aria-modal="true" aria-label="Exit Cat Arena"><div class="voidPauseCard"><div class="cat-kicker">UNTIL THE NEXT HUNT</div><h2>Leave the arena?</h2><p>Close Cat Arena and return to your device.</p><button id="catExitConfirm" class="primary">EXIT GAME</button><button id="catExitCancel">STAY</button></div></div>');
 el('catExit').onclick=()=>{el('catExitDialog').hidden=false;el('catExitCancel').focus()};
 el('catExitCancel').onclick=()=>el('catExitDialog').hidden=true;
 el('catExitConfirm').onclick=()=>{
   if(location.protocol==='file:'){confirm('CAT_ARENA_EXIT');}
   else{el('catExitDialog').querySelector('p').textContent='You can now close this browser tab.';window.close();}
 };
 window.catBack=()=>{
   if(!el('catExitDialog').hidden){el('catExitDialog').hidden=true;return}
   if(active){if(voidEditorOpen)voidFinishHudEdit();else if(voidSettingsFromPause)voidReturnToPause();else if(voidPauseOpen)voidClosePause();else voidOpenPause();return}
   if(document.body.classList.contains('cat-home-settings')){el('settingsResume').click();return}
   if(route==='home')el('catExit').click();else page(route==='servers'||(route==='maps'&&mode==='host')?'multi':'home');
 };
 const url=new URL(location.href), initial=url.searchParams.get('catPage'),join=url.searchParams.get('catJoin');
 if(initial==='host'){mode='host';page('maps')}else if(initial==='play'){mode='solo';page('maps')}else if(initial==='join'){page('servers');if(join&&/^[A-HJ-NP-Z2-9]{6}$/.test(join))netConnect('join',join)}else page('home');
 // Prevent stale launch instructions replaying on subsequent reloads.
 url.searchParams.delete('catPage');url.searchParams.delete('catJoin');try{history.replaceState(null,'',url.href)}catch{}
 window.CAT_UI={page,returnMenu,preview,get route(){return route}};
})();
