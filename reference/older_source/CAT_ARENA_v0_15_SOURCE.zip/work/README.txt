CAT ARENA v0.15 — THE FERAL ORDER
Based on VOID ARENA v0.13 Helios Optimized.

DELIVERABLE
CAT_ARENA_v0_15_GRAPHICS_FIXED.apk
Package com.voidarena.helios; version code 15; target SDK 36.
Uses the same development signing key/certificate as v0.13, allowing an update.
The launcher label is CAT ARENA. Internal package and network protocol IDs remain compatible.

UI
Original feline crest, charcoal iron panels, brass borders, bone typography,
crimson emphasis. The HUD, touch controls, pause menu, settings and loading
screen share the new palette. No visible Quake/Q3 branding remains.
Main menu: Play / Multiplayer / Settings / Exit.
Play: map choices, actual renderer screenshot, Enter Arena.
Multiplayer: Host -> map selection and server details; Join -> actual live list.
Cross-map joins reload the correct map and preserve relay/player information.
Pause: resume, settings, HUD customization, choose map, return to main menu.
Return stops the simulation, clears input, disconnects the room, and resets UI.
Native Back invokes context-aware menu/pause navigation.
Native Exit uses the WebChromeClient confirmation callback to finish the task.

MAP PREVIEWS
Generated locally by the actual game renderer on opening map selection.
A small 640x360 JPEG is kept in memory for that page.
Camera positions derive from the game's own map tours. No generated concept
images or fake server listings are used. Preview preparation may briefly take
time on slower phones; the normal game load screen still follows Play.
The v0.13 renderer and map performance optimizations are retained.

MULTIPLAYER
Requires a reachable, compatible existing relay server. No live service was
deployed in this revision. Enter its ws:// or wss:// address under the advanced
server address section. The address persists across restarts and map changes.
No relay endpoint was provided with the source; APK defaults remain localhost
until a custom address is entered. Hosting creates a room on that relay; the
phone does not become a standalone public relay.

BUILD (from archive root)
python3 work/build_native.py
python3 work/package_apk.py
python3 work/verify_apk.py
Python cryptography is required for APK packaging/signature validation.
assets/index.html is standalone and contains the current UI CSS/JS inline.
cat-ui.css and cat-ui.js are editable copies of those appended modules.

VALIDATION
54 inline scripts pass Node syntax parsing.
Menu controller tests run with a mock DOM and engine: solo, preview state
restore, map switching, settings/back, host flow, browsing, cross-map joins,
return-to-menu teardown, native exit dispatch, and reload routes pass.
Static HTML scan: no duplicate IDs or visible legacy branding.
APK v2 RSA signature, certificate, content digests, ZIP CRCs, embedded HTML
and rebuilt native DEX match and verify.
Live Chromium WebGL2 screenshot/graphics-preset tests completed in v0.15.
No Android device/emulator install or live multiplayer playtest was possible.
Performance on the target Android device remains unmeasured.

PRIVATE DEVELOPMENT KEY
helios-signing-key.pem is retained for future update compatibility.
Keep this source archive private. Distribute the APK, not the key.

GRAPHICS RELIABILITY FIX · v0.15
Root 1: Map selection preview constructed world before the Bastion geometry kit
        registered its images and shader materials. The first material upload
        therefore contained only 30 images instead of all 45, and 420 kit
        placements raised unknown-material warnings. The preview now awaits kit
        preparation, and Q3MAT also handles late scripts by rebuilding its
        texture arrays and shader programs.
Root 2: Switching 16-bit/32-bit textures after a low picmip inherited a nonzero
        TEXTURE_BASE_LEVEL during model mipmap generation. On some WebGL drivers
        this left incomplete/mixed-format mip chains and caused black guns or
        objects. Base level 0 is now set before every regeneration.
Root 3: Texture format conversions now use explicit packed RGBA4444 uploads,
        including world and model textures, instead of relying on driver
        conversions for all platforms. Material arrays safely reallocate.

TESTED
Live Chromium WebGL2 test with actual map initialization and shader compilation.
Preset cycle normal -> fastest -> high -> fast -> fastest -> normal:
WebGL errors 0, JS page errors 0, unknown-material warnings 0.
All 40 Bastion kit assets prepared; 420 placed; 87 shader materials.
Android target phone installation not available in this runtime.
