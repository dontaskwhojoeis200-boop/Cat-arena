// HELIOS CRUCIBLE — original octagonal reactor cathedral, 2026-11.
window.VOID_SHADER_SCRIPTS.push({file:'scripts/helios.shader',text:`
textures/helios/coolant
{
 cull none
 surfaceparm nolightmap
 {
  map textures/gallery/plasma
  tcMod scale 2 2
  tcMod scroll .035 -.08
  rgbGen const ( .06 .42 .52 )
 }
 {
  map textures/gallery/energy
  blendFunc add
  tcMod scroll -.025 .06
  rgbGen const ( .02 .13 .19 )
 }
}
textures/helios/strip
{
 cull none
 surfaceparm nolightmap
 {
  map $whiteimage
  rgbGen const ( .23 .75 .88 )
 }
}
`});
window.VOID_MAP_REGISTRY['helios-crucible']=function(K){
 const C=58.5, W=K.createWorld({name:'FERAL CLAW // HELIOS CRUCIBLE',version:'hc-1.0',
 history:'A solar containment cathedral. The furnace still burns above a flooded service vault.',
 heights:{L1:-4,L2:0,L3:7,roof:12},center:[C,C],sky:{sunAzimuth:-.8,sunElevation:.12},
 landmarks:[{id:'core',title:'Helios Core'},{id:'sump',title:'Coolant Vault'},{id:'bridge',title:'Transfer Bridges'},{id:'gallery',title:'Observation Cloister'},{id:'control',title:'Control Chapel'}]});
 const P=(x,y)=>[C+x,C+y],R=(x0,y0,x1,y1)=>K.rect(C+x0,C+y0,C+x1,C+y1);
 const frames=Array.from({length:8},(_,i)=>K.frame(C,C,i));
 const kit=(a,p,z,yaw=0,scale=1)=>W.kit(a,...p,z,yaw,{scale});
 const face=(a,f,r,t,z,scale=1)=>kit(a,f.P(r,t),z,f.th-Math.PI/2,scale);
 function rail(a,b,z){W.railing(a,b,{z,h:1.05,render:false});const len=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.ceil(len/4),yaw=Math.atan2(b[1]-a[1],b[0]-a[0]);
 for(let j=0;j<n;j++){const u=(j+.5)/n;kit('BA_19',[a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u],z,yaw,[len/n/4,1,.875]);}}
 const glow=(poly3,shader='textures/helios/strip')=>W.surface({poly3,shader,uv:[[0,0],[1,0],[1,1],[0,1]]});
 const box=(poly,z0,z1,look='pillar')=>W.solid({poly,z0,z1,kind:'block',look});
 W.footprint(K.octagon(C,C,37));W.region('sump','COOLANT VAULT','reactor',K.octagon(C,C,18));
 W.cavity(K.octagon(C,C,18),-4,0,{look:'pitwall'});W.ground(K.octagon(C,C,18),-4,{look:'pitfloor',region:'sump'});
 // Raised core plinth with a narrow, animated coolant moat, safely inset below floor level.
 W.solid({poly:K.octagon(C,C,3.1),z0:-4,z1:-3,kind:'equipment',look:'machine'});
 kit('BA_24',P(0,0),-3.8,0,[1.15,1.15,1]);kit('BA_28',P(0,0),-2.8,Math.PI/8);
 for(let i=0;i<8;i++){
  const f=frames[i];const poly=f.band(3.3,4.5);
  glow(poly.map(p=>[...p,-3.96]),'textures/helios/coolant');
  W.light(...f.P(4.2,0),-3.3,{range:6,power:.6,color:[.12,.65,.95]});
 }
 // Four tall piers frame a visible energy shaft; a suspended octagonal turbine crown.
 for(const [x,y] of [[-3.6,-3.6],[3.6,-3.6],[3.6,3.6],[-3.6,3.6]]){
  box(R(x-.65,y-.65,x+.65,y+.65),-4,16.4,'pillar');
  for(let z=-4;z<16;z+=4)kit('BA_27',P(x,y),z,Math.atan2(-x,y),[.8,.8,1]);
 }
 for(const [x,y] of [[-.8,-.8],[.8,-.8],[.8,.8],[-.8,.8]])W.solid({poly:R(x-.15,y-.15,x+.15,y+.15),z0:-2,z1:14,kind:'equipment',render:false});
 for(let z=-2;z<14;z+=4)kit('BA_29',P(0,0),z,Math.PI/4);
 kit('BA_25',P(0,0),14,0,[1.7,1.7,1.2]);
 for(let i=0;i<8;i++){
  const f=frames[i];box(f.band(4.8,6.2),14.3,16,'machine');
  face('BA_35',f,6.25,0,9.8,[1.2,1,1.1]);
  W.light(...f.P(5.9,0),13.7,{range:9,power:.65,warm:true});
 }
 for(const [w,shader] of [[.9,'reactor_beam'],[3.1,'reactor_glow']])glow([[C-w/2,C,-2.2],[C+w/2,C,-2.2],[C+w/2,C,15],[C-w/2,C,15]],'models/bastion/'+shader);
 for(const z of [-2,14])glow([[C-2,C,z-2],[C+2,C,z-2],[C+2,C,z+2],[C-2,C,z+2]],'models/bastion/reactor_flare');
 for(const z of [-1,5,11])W.light(C,C,z,{range:22,power:1.6,kind:'reactor'});
 // Eight industrial bays: broad lower ring, enclosed service aisle, continuous upper cloister.
 for(let i=0;i<8;i++){
  const f=frames[i],cardinal=i%2===0,span=f.tMax(18);
  W.region('bay-'+i,['TURBINE HALL','BROKEN CHAPEL','NORTH TRANSFER','CONTROL CHAPEL','COOLING STATION','WEST ARMORY','SOUTH TRANSFER','EXHAUST HALL'][i],'hall',f.band(18,37));
  W.ground(f.band(18,36),0,{look:'floor',region:'bay-'+i});
  // Stairwell cut out of the upper deck, never capped by an invisible ceiling.
  if(cardinal){
   W.deck(f.band(26,32),7,{look:'deck'});
   for(const [lo,hi] of [[-100,-9],[5,100]])W.deck(f.band(32,35,lo,hi),7,{look:'deck'});
   W.deck(f.band(35,36),7,{look:'deck'});
   W.ramp({id:'upper-stair-'+i,poly:f.box(32,35,-9,5),from:f.P(33.5,-9),dir:f.V(0,1),len:14,z0:0,z1:7,stairs:true,solid:true,render:false});
   for(let j=0;j<2;j++)kit('BA_15',f.P(33.5,-5.5+7*j),3.5*j,f.th,[1,7/6,.875]);
   W.railing(f.P(32,-9),f.P(32,5),{za:0,zb:7,h:1.05});
   rail(f.P(32,-9),f.P(32,5),7);rail(f.P(32,-9),f.P(35,-9),7);
  }else W.deck(f.band(26,36),7,{look:'deck'});
  // Broad door and high observation opening. Curved lintel dressing stays above head height.
  W.bandWall(f,29.3,30,0,12,[{t0:-3,t1:3,z0:0,z1:4.3},{t0:-9,t1:9,z0:7,z1:10.8}],{look:'bastion',massive:false});
  const breach=i===1?[{t0:-4,t1:4,z0:7,z1:14}]:[];
  W.bandWall(f,36,37,0,13.8,breach,{look:'bastion-outer'});
  W.roof(f.band(30,36),12.2,{look:'roof',thickness:.6});
  // Lower-ring pit rails keep clearly marked gaps for ramps and bridge ends.
  const gaps=cardinal?[[-2.2,2.2]]:[];
  if(i===0)gaps.push([-8,-4]); if(i===4)gaps.push([4,8]);
  let t=-span;for(const [a,b] of gaps.sort((a,b)=>a[0]-b[0])){if(a>t)rail(f.P(18,t),f.P(18,Math.min(a,span)),0);t=Math.max(t,b);}if(t<span)rail(f.P(18,t),f.P(18,span),0);
  // Four radial descent ramps create independent routes into the lowest floor.
  if(cardinal){W.ramp({id:'vault-ramp-'+i,poly:f.box(8,18,-2,2),from:f.P(8,0),dir:f.V(1,0),len:10,z0:-4,z1:0,solid:true,look:'ramp'});
   W.railing(f.P(8,-2),f.P(18,-2),{za:-4,zb:0,h:.9});W.railing(f.P(8,2),f.P(18,2),{za:-4,zb:0,h:.9});}
  // Balcony rails, interrupted at the upper bridge mouths.
  const bspan=f.tMax(26);const bridgeGap=i===2?[-8,-4]:i===6?[4,8]:null;
  if(bridgeGap){rail(f.P(26,-bspan),f.P(26,bridgeGap[0]),7);rail(f.P(26,bridgeGap[1]),f.P(26,bspan),7);}else rail(f.P(26,-bspan),f.P(26,bspan),7);
  // Kit panels seated on collision faces; steel ribs rise above the roof silhouette.
  for(const t of [-10,-6,6,10]){
   face(['BA_01','BA_06','BA_07'][(i+Math.abs(t))%3],f,29.38,t,0);
   face('BA_01',f,36.05,t,7);
  }
  for(const t of [-12,12]){
   box(f.box(28.4,30,t-.55,t+.55),0,14.2,'pillar');
   for(const z of [0,4,8])face('BA_04',f,29,t,z);
   face('BA_35',f,28.35,t,6.4,[1,1,1.4]);
  }
  face('BA_33',f,29.05,0,4.6,[2,1,1]);
  W.light(...f.P(27.8,0),4.7,{range:12,power:1.0,warm:true,fixture:'none'});
  W.light(...f.P(33,6),3.4,{range:9,power:.8,color:i%2?[.25,.66,.85]:[1,.68,.33],fixture:'panel'});
  W.light(...f.P(33,0),10.5,{range:11,power:.8,color:[.35,.67,.88],fixture:'panel'});
  // Cyan guide strips along the upper fascia, small enough to retain material detail.
  const a=f.P(26.03,-8),b=f.P(26.03,8);glow([[...a,6.25],[...b,6.25],[...b,6.36],[...a,6.36]]);
  // Vault vents and warning lamps.
  for(const t of [-5,5]){face('BA_06',f,18.08,t,-4,[.8,1,1]);face('BA_34',f,17.8,t,-2.5);
   W.light(...f.P(17,t),-1.8,{range:7,power:.65,color:[.2,.72,.85]});}
  // Pipework and colonnade lighting, under the open upper balcony.
  for(const t of [-9,9]){face('BA_31',f,28.9,t,3.8);face('BA_30',f,28.8,t,7,[1,1,.85]);}
  if(!cardinal){face('BA_36',f,35.3,-4,0);box(f.box(34.5,36,-5,-3),0,1.25,'equipment');
   kit('BA_32',f.P(23.5,5),0,f.th);box(f.box(22.5,24.5,4,6),0,1.1,'equipment');}
  for(const [r,t,z] of [[23,3,0],[33,8,0],[28,-4,7]]){const p=f.P(r,t);W.spawn(...p,z,Math.atan2(C-p[1],C-p[0]),'bay-'+i);}
  W.pickup(...f.P(33,7),0);W.pickup(...f.P(28,6),7);W.pickup(...f.P(14,-5),-4);
 }
 // Two broad crossing transfers: stacked, not intersecting. Real undersides and rails.
 W.deck(R(-18,-8,18,-4),0,{look:'deck',thickness:.5,render:false,id:'lower-transfer'});
 for(let x=-14;x<18;x+=8)kit('BA_11',P(x,-6),-.5,-Math.PI/2);
 kit('BA_11',P(16,-6),-.5,-Math.PI/2,[1,.5,1]);
 rail(P(-18,-8),P(18,-8),0);rail(P(-18,-4),P(18,-4),0);
 W.deck(R(4,-26,8,26),7,{look:'deck',thickness:.5,render:false,id:'upper-transfer'});
 for(let y=-22;y<26;y+=8)kit('BA_11',P(6,y),6.5,0);
 // Last four metres use a half-length module; no visible bridge extends beyond its collider.
 kit('BA_11',P(6,24),6.5,0,[1,.5,1]);
 rail(P(4,-26),P(4,26),7);rail(P(8,-26),P(8,26),7);
 for(const y of [-20,20]){box(R(5.3,y-.7,6.7,y+.7),0,6.5,'pillar');kit('BA_26',P(6,y),0,0,[.7,.7,1.625]);}
 W.pickup(...P(0,-6),0);W.pickup(...P(6,0),7);
 // Vault launchers clear the upper bridge rails and land on the transfer deck.
 W.pad({id:'vault-launch-north',x:C+11,y:C+11,z:-4,r:1,apex:[C+7.75,C+11,10.8]});
 W.pad({id:'vault-launch-south',x:C+2.8,y:C-13,z:-4,r:1,apex:[C+4.9,C-13,10.8]});
 // Distinct sculpted turbine drums in the diagonal bays (Bezier surfaces with explicit simple colliders).
 for(const i of [1,5]){const f=frames[i],p=f.P(24,0);
  W.solid({poly:K.circle(...p,1.65,12),z0:0,z1:4,kind:'equipment',render:false});
  W.patch({id:'turbine-'+i,ctrl:Q3Patch.column(...p,1.65,0,4),look:'rust',collide:'none'});
  kit('BA_25',p,3.7,0,[.62,.62,.4]);
  W.light(...f.P(22,0),2.5,{range:8,power:.7,warm:true});}
 // A live reactor monitor in the control chapel, recessed above its console.
 const f=frames[3],q0=f.P(35.85,-2),q1=f.P(35.85,2);
 W.portal({id:'core-monitor',poly3:[[...q0,1.7],[...q1,1.7],[...q1,3.9],[...q0,3.9]],normal:[-f.c,-f.s,0],shader:'textures/gallery/monitor',view:'feed',camera:{x:C+16,y:C-16,z:6,yaw:2.35,pitch:.05},fov:85,updateHz:8});
 // Ruined upper chapel: jagged wall fragments flank a framed sunset aperture.
 for(const t of [-4.8,4.8])face('BA_40',frames[1],36,t,7,[1,1,1.7]);
 kit('BA_38',frames[1].P(34,9),7,.5,[.85,.85,.7]);
 box(frames[1].box(32.6,35.3,7.8,10.2),7,7.55,'rubble');
 rail(frames[1].P(36,-4),frames[1].P(36,4),7);
 // Broad exterior buttresses at the octagon corners ground the silhouette.
 for(let i=0;i<8;i++){const p=K.cornerPoint(C,C,i,35.8);kit('BA_05',p,11.8,i*Math.PI/4,[1.4,1.4,1.5]);}
 for(const i of [1,3,5,7]){const p=frames[i].P(12,-3);W.spawn(...p,-4,Math.atan2(C-p[1],C-p[0]),'vault');}
 W.note('Original Helios layout: three stacked levels; four lower ramps, four upper stairs; two launch pads.');
 return W;
};
