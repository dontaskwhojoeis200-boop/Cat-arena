const fs=require('fs'),vm=require('vm'),assert=require('assert');
class El{
 constructor(tag='div',attrs={}){this.tagName=tag;this.attrs={...attrs};this.children=[];this.parentElement=null;this.style={};this.events={};this.hidden='hidden' in attrs;this.disabled=false;this.value=attrs.value||'';this._text='';this.className=attrs.class||'';const self=this;this.classList={add(...c){self.className=[...new Set([...self.className.split(' '),...c])].join(' ')},remove(...c){self.className=self.className.split(' ').filter(x=>!c.includes(x)).join(' ')},contains(c){return self.className.split(' ').includes(c)},toggle(c,on){on=on??!this.contains(c);on?this.add(c):this.remove(c);return on}}}
 get id(){return this.attrs.id} get textContent(){return this._text+this.children.map(c=>c.textContent).join('')}set textContent(v){this.children=[];this._text=String(v)}
 append(...els){for(const e of els){if(e.parentElement)e.remove();e.parentElement=this;this.children.push(e)}} remove(){if(this.parentElement){this.parentElement.children=this.parentElement.children.filter(x=>x!==this);this.parentElement=null}}
 replaceChildren(...els){this.children.forEach(c=>c.parentElement=null);this.children=[];this._text='';this.append(...els)}
 setAttribute(k,v){this.attrs[k]=v} getAttribute(k){return this.attrs[k]}
 matches(q){if(q.startsWith('#'))return this.id===q.slice(1);if(q.startsWith('.'))return this.classList.contains(q.slice(1));if(q.startsWith('['))return q.slice(1,-1) in this.attrs;return this.tagName===q}
 querySelectorAll(q){let a=[];for(const c of this.children){if(q.split(',').some(x=>c.matches(x.trim())))a.push(c);a.push(...c.querySelectorAll(q))}return a}
 querySelector(q){return this.querySelectorAll(q)[0]||null} closest(q){return this.matches(q)?this:this.parentElement?.closest(q)}
 insertAdjacentHTML(where,html){const els=parse(html).children.slice();if(where==='beforeend')this.append(...els);else if(where==='afterend'){const p=this.parentElement,i=p.children.indexOf(this);for(const e of els)e.parentElement=p;p.children.splice(i+1,0,...els)}else throw Error(where)}
 addEventListener(n,fn,capture=false){(this.events[n]??=[]).push({fn,capture})}
 click(){if(this.disabled)return;let stopped=false;const ev={preventDefault(){},stopImmediatePropagation(){stopped=true},stopPropagation(){}};for(const e of [...(this.events.click||[])].sort((a,b)=>!!b.capture-!!a.capture)){e.fn(ev);if(stopped)return}this.onclick?.(ev)}
 focus(){this.focused=true}
 getContext(){return {drawImage(){}}}toDataURL(){return 'data:image/jpeg;base64,capture'}
}
function parse(html){const root=new El(),stack=[root];const voids=new Set(['input','img','br','hr','meta','link']);for(const m of html.matchAll(/<\/?[a-zA-Z][^>]*>|[^<]+/g)){const t=m[0];if(t.startsWith('</')){if(stack.length>1)stack.pop();continue}if(t.startsWith('<')){const name=t.match(/^<([\w-]+)/)[1];let a={};for(const x of t.slice(name.length+1,-1).matchAll(/([\w-]+)(?:="([^"]*)"|='([^']*)')?/g))a[x[1]]=x[2]??x[3]??'';const e=new El(name,a);stack.at(-1).append(e);if(!voids.has(name)&&!t.endsWith('/>'))stack.push(e)}else stack.at(-1)._text+=t}return root}
const html=fs.readFileSync('source/work/assets/index.html','utf8');
function setup(query=''){
 const clean=html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/g,'').replace(/<style\b[^>]*>[\s\S]*?<\/style>/g,'').replace(/<!--[\s\S]*?-->/g,'');
 const dom=parse(clean),body=dom.querySelector('body'),doc={body,getElementById:id=>dom.querySelector('#'+id),createElement:t=>new El(t),querySelectorAll:q=>dom.querySelectorAll(q),exitPointerLock(){doc.pointerLockElement=null}};
 const storage=new Map();let navigated='',confirmed=false;
 const ctx={console,URL,Set,Map,Promise,document:doc,location:{href:'file:///android_asset/index.html'+query,protocol:'file:',replace(u){navigated=u}},history:{replaceState(){}},localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},setTimeout(fn){fn()},requestAnimationFrame(fn){fn()},confirm(v){confirmed=v},
 active:false,player:{x:1,y:2,z:3,a:0,pitch:0},bots:[{id:1}],canvas:new El('canvas'),q3Reset(){},render(){},loadMap(){},netBrowseServers(){ctx.browsed=true},netConnect(role,code){ctx.connected={role,code}},audiostart(){},showFovPanel(v){ctx.fovPanelOpen=v},settingsTab(t){assert(['gfx','touch'].includes(t));ctx.tab=t},resetTouchInput(){},netSetBadge(){},voidClosePause(){},voidOpenPause(){},voidReturnToPause(){},voidFinishHudEdit(){},beginLoadedGameplay(){ctx.active=true},PAUSE:doc.getElementById('voidPauseOverlay'),netPlayers:new Map(),netClients:new Map(),loadingNetRelayQueue:[],netSocket:null};
 ctx.window=ctx;ctx.window.close=()=>{};
 ctx.VOID_ACTIVE_MAP='helios-crucible';
 ctx.VOID_MAPS={'helios-crucible':{id:'helios-crucible-v1',title:'HELIOS CRUCIBLE'},'bastion-keep':{id:'bastion-keep-v1',title:'BASTION KEEP'},'reactor-bastion':{id:'reactor-bastion-v1',title:'REACTOR BASTION'},'q3-gallery':{id:'q3-gallery-v1',title:'THE ARSENAL'}};
 vm.createContext(ctx);vm.runInContext(fs.readFileSync('source/work/cat-ui.js','utf8'),ctx);
 return {ctx,doc,get:id=>doc.getElementById(id),navigation:()=>navigated,confirmation:()=>confirmed};
}
(async()=>{
 let t=setup(),{ctx,get}=t;
 assert.equal(ctx.CAT_UI.route,'home');assert(!get('catHome').hidden);
 get('catPlay').click();await ctx.CAT_UI.preview();assert.equal(ctx.CAT_UI.route,'maps');assert(!get('start').hidden);assert(get('catCoopDock').hidden);assert(!get('catMapImage').hidden);assert.equal(ctx.player.x,1);assert.equal(ctx.bots[0].id,1);
 get('catMapOptions').children[1].click();assert(t.navigation().includes('map=bastion-keep'));assert(t.navigation().includes('catPage=play'));
 ctx.CAT_UI.page('home');get('catSettings').click();assert.equal(ctx.tab,'gfx');assert(ctx.fovPanelOpen);get('settingsResume').click();assert(!ctx.fovPanelOpen);assert.equal(ctx.CAT_UI.route,'home');
 get('catMultiplayer').click();assert.equal(ctx.CAT_UI.route,'multi');get('catHostChoice').click();assert.equal(ctx.CAT_UI.route,'maps');assert(get('start').hidden);assert(!get('coopHost').hidden);assert(!get('catCoopDock').hidden);
 ctx.CAT_UI.page('multi');get('catJoinChoice').click();assert.equal(ctx.CAT_UI.route,'servers');assert(!get('serverList').hidden);assert(get('coopHost').hidden);assert(!get('coopRefresh').hidden);
 ctx.catJoinServer({mapId:'bastion-keep-v1',id:'ABCDEF'});assert(t.navigation().includes('catJoin=ABCDEF'));
 ctx.catJoinServer({mapId:'helios-crucible-v1',id:'ABCDEF'});assert.equal(ctx.connected.role,'join');
 ctx.active=true;ctx.netSocket={close(){ctx.closed=true}};get('catReturnMenu').click();assert(!ctx.active);assert(ctx.closed);assert.equal(ctx.netMode,'solo');assert.equal(ctx.CAT_UI.route,'home');assert(ctx.PAUSE.hidden);
 get('catExit').click();assert(!get('catExitDialog').hidden);get('catExitConfirm').click();assert.equal(t.confirmation(),'CAT_ARENA_EXIT');
 for(const page of ['play','host','join']){let z=setup('?catPage='+page+(page==='join'?'&catJoin=ABCDEF':''));assert.equal(z.ctx.CAT_UI.route,page==='join'?'servers':'maps');if(page==='join')assert.equal(z.ctx.connected.code,'ABCDEF')}
 console.log('PASS: solo, screenshots/restored state, map reload, settings/back, host, live browse, cross-map join, teardown, native exit and reload routes.');
})().catch(e=>{console.error(e);process.exitCode=1});
