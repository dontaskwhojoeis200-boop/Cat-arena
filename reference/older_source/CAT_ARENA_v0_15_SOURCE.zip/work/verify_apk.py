import struct,hashlib,zipfile
from pathlib import Path
from cryptography import x509
from cryptography.hazmat.primitives import serialization,hashes
from cryptography.hazmat.primitives.asymmetric import padding
p=Path('output/CAT_ARENA_v0_15_GRAPHICS_FIXED.apk');b=p.read_bytes();eo=b.rfind(b'PK\x05\x06');co=struct.unpack_from('<I',b,eo+16)[0]
assert b[co-16:co]==b'APK Sig Block 42';sz=struct.unpack_from('<Q',b,co-24)[0];start=co-sz-8;assert struct.unpack_from('<Q',b,start)[0]==sz
pairlen=struct.unpack_from('<Q',b,start+8)[0];assert struct.unpack_from('<I',b,start+16)[0]==0x7109871a
value=b[start+20:start+16+pairlen]
def take(b,p=0):
 n=struct.unpack_from('<I',b,p)[0];return b[p+4:p+4+n],p+4+n
signers,_=take(value);signer,_=take(signers);signed,p0=take(signer);sigs,p0=take(signer,p0);pub,p0=take(signer,p0);assert p0==len(signer)
sg,_=take(sigs);assert struct.unpack_from('<I',sg)[0]==0x0103;sig,_=take(sg,4)
key=serialization.load_der_public_key(pub);key.verify(sig,signed,padding.PKCS1v15(),hashes.SHA256())
digests,p0=take(signed);certs,p0=take(signed,p0);cert,_=take(certs)
assert x509.load_der_x509_certificate(cert).public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)==pub
dr,_=take(digests);digest,_=take(dr,4)
e=bytearray(b[eo:]);struct.pack_into('<I',e,16,start);chunks=[]
for sec in (b[:start],b[co:eo],e):
 for i in range(0,len(sec),1048576):
  c=sec[i:i+1048576];chunks.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(c))+c).digest())
assert hashlib.sha256(b'\x5a'+struct.pack('<I',len(chunks))+b''.join(chunks)).digest()==digest
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 assert z.read('assets/index.html')==Path('work/assets/index.html').read_bytes()
 assert z.read('classes.dex')==Path('work/classes.dex').read_bytes()
 assert b'com.voidarena.helios' in z.read('AndroidManifest.xml')
print('PASS: RSA signature, certificate/public key, all APK v2 content digests, ZIP CRCs, embedded HTML and Cat Arena native activity.')
