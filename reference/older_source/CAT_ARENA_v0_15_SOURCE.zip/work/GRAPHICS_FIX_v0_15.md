# Cat Arena v0.15: graphics preset fixes

1. Asynchronous Bastion material loading was bypassed by map previews. The first renderer init ran before 40 models and their texture maps were registered, so the renderer silently skipped 420 placements. Switching presets rebuilt the material texture array, changing the appearance of in-game geometry. Preview now awaits the kit; late shader scripts call finishLoad to rebuild arrays/programs.
2. Model texture reuploads did not reset TEXTURE_BASE_LEVEL before gl.generateMipmap. A preceding picmip 2 setting meant changing texture bit depth left a mixed mip chain, creating incomplete black models and weapons. All texture format reuploads now set base level 0 while regenerating mips, then reapply picmip.
3. Use explicit GL_UNSIGNED_SHORT_4_4_4_4 packed uploads for 16-bit textures across material arrays, world layers and models.
4. Added safe handling for detail-only shaders, and kit load errors now stop world construction instead of producing partial maps.

**Regression test:** Full WebGL2 gameplay initialization in Chromium, then normal -> fastest -> high -> fast -> fastest -> normal. Zero GL errors, zero JS errors, zero unknown-material warnings. Full Android hardware/driver testing is not available here.
