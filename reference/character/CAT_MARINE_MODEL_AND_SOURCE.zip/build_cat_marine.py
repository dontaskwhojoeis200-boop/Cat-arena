#!/usr/bin/env python3
"""Build a deliberately tiny skinned CAT ARENA cat-marine GLB from the supplied reference.
Offline procedural stand-in for Meshy. GLB is self-contained with PNG textures and seven animations.
Requires numpy and Pillow, optional trimesh for validation. Uses standard glTF 2.0.
"""
from PIL import Image, ImageEnhance, ImageFilter
from pathlib import Path
from io import BytesIO
import struct, json, math, random, numpy as np
from collections import defaultdict

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'reference.png'
OUT=ROOT/'cat_marine_rigged.glb'
random.seed(63)

# Reference crop is the front-facing face on the illustrated model, not an AI reconstruction.
image=Image.open(SRC).convert('RGB')
face=image.crop((65,93,236,187)).resize((256,256),Image.Resampling.LANCZOS)
face=ImageEnhance.Contrast(face).enhance(1.13)
face=ImageEnhance.Color(face).enhance(0.95)
face=face.filter(ImageFilter.UnsharpMask(radius=1.5,percent=100,threshold=3))
face.save(ROOT/'cat_face_256.png')
# Generate mottled Quake-era camouflage, no high-res PBR maps.
rng=np.random.default_rng(88); s=256
camo=np.empty((s,s,3),np.uint8); camo[:]=[91,92,54]
small=rng.integers(0,5,(16,16)); pal=np.array([[94,99,58],[68,79,47],[119,101,64],[120,92,55],[52,60,45]],np.uint8)
for y in range(16):
 for x in range(16): camo[y*16:(y+1)*16,x*16:(x+1)*16]=pal[small[y,x]]
noise=rng.normal(0,9,(s,s,1));camo=np.clip(camo.astype(float)+noise,0,255).astype('uint8')
armor_png=Image.fromarray(camo,'RGB');armor_png.save(ROOT/'armor_camo_256.png')

def png_bytes(im):
 mem=BytesIO(); im.save(mem,format='PNG');return mem.getvalue()
tex_face=png_bytes(face); tex_armor=png_bytes(armor_png)

names=['Root','Pelvis','Spine_01','Spine_02','Neck','Head',
 'Shoulder_L','Elbow_L','Wrist_L','Grip_L',
 'Shoulder_R','Elbow_R','Wrist_R','Grip_R',
 'Hip_L','Knee_L','Ankle_L','Hip_R','Knee_R','Ankle_R','Weapon']
parents=[None,0,1,2,3,4,3,6,7,8,3,10,11,12,1,14,15,1,17,18,12]
loc=[(0,0,0),(0,.74,0),(0,.13,0),(0,.22,0),(0,.19,0),(0,.31,0),
 (.47,.12,0),(.04,-.26,.13),(0,-.23,.20),(0,-.02,.07),
 (-.47,.12,0),(-.04,-.26,.13),(0,-.23,.20),(0,-.02,.07),
 (.19,-.05,0),(0,-.32,0),(0,-.24,0),(-.19,-.05,0),(0,-.32,0),(0,-.24,0),
 (.25,.34,.12)]
loc=np.array(loc,float)
world=[]
for i,p in enumerate(parents):world.append((world[p] if p is not None else np.zeros(3))+loc[i])
world=np.array(world)

# Each colored primitive is a piece of the *same skinned mesh*. Surface tessellation is
# intentionally only 2 triangles per cuboid face, with the 256x256 textures doing the detail.
materials={
 0:{'name':'Camo_256','color':[1,1,1,1],'tex':1,'metallic':0.1,'roughness':0.95},
 1:{'name':'Dark_Armor','color':[0.19,0.23,0.16,1],'metallic':0.45,'roughness':0.83},
 2:{'name':'Fur_Ears','color':[.62,.34,.20,1],'metallic':0,'roughness':1},
 3:{'name':'Weathered_Boots','color':[.29,.24,.18,1],'metallic':.15,'roughness':.92},
 4:{'name':'Gun_Steel','color':[.21,.20,.18,1],'metallic':.7,'roughness':.7},
 5:{'name':'Magenta_Status','color':[1.0,.15,.65,1],'metallic':.1,'roughness':.28,'emissive':[.18,.015,.085]},
 6:{'name':'Cat_Face_256','color':[1,1,1,1],'tex':0,'metallic':0,'roughness':1}
}
parts=defaultdict(lambda:{'pos':[],'nor':[],'uv':[],'j':[],'w':[],'idx':[]})
poly_count=0
FACES=[(1,0,3,2,(0,0,-1)),(4,5,6,7,(0,0,1)),(0,4,7,3,(-1,0,0)),
       (5,1,2,6,(1,0,0)),(2,3,7,6,(0,1,0)),(0,1,5,4,(0,-1,0))]
# x,y,z corners for the 6 faces above

def emit(mat,vertices,normal,uvs,bone):
 global poly_count
 b=parts[mat];k=len(b['pos']);
 for p,uv in zip(vertices,uvs):
  b['pos'].append(list(map(float,p)));b['nor'].append(list(map(float,normal)))
  b['uv'].append(list(map(float,uv)));b['j'].append([bone,0,0,0]);b['w'].append([1.,0,0,0])
 b['idx'].extend([k,k+1,k+2,k,k+2,k+3]);poly_count+=2

def box(center,size,bone,mat,face_tex=False):
 c=np.array(center,float);d=np.array(size,float)/2
 # ccw viewed from outside: back -z, front +z, left -x, right+x, top+y, bottom-y
 verts=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],
                 [-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],float)*d+c
 for i0,i1,i2,i3,normal in FACES:
  front=face_tex and normal==(0,0,1)
  uvs=[(0,0),(1,0),(1,1),(0,1)]
  if front:uvs=[(0,1),(1,1),(1,0),(0,0)]
  # mesh UV: (0,0) bottom left, (1,1) top right glTF. yes.
  emit(6 if front else mat,[verts[t] for t in (i0,i1,i2,i3)],normal,uvs,bone)

def ear(cx):
 global poly_count
 # Pyramid taper matching sharp cat ears. each triangular face: one triangle (not quad).
 top=np.array([cx+(0.045 if cx<0 else -.045),2.075,.0])
 base=np.array([[cx-.13,1.86,-.235],[cx+.13,1.86,-.235],[cx+.13,1.86,.15],[cx-.13,1.86,.15]])
 for a,b in [(0,1),(1,2),(2,3),(3,0)]:
  q=parts[2];st=len(q['pos']);pts=[base[a],base[b],top]
  n=np.cross(pts[1]-pts[0],pts[2]-pts[0]);n=n/(np.linalg.norm(n)+1e-9)
  for v,uv in zip(pts,[(0,0),(1,0),(.5,1)]):
   q['pos'].append(v.tolist());q['nor'].append(n.tolist());q['uv'].append(uv);q['j'].append([5,0,0,0]);q['w'].append([1,0,0,0])
  q['idx'].extend([st,st+1,st+2]);poly_count+=1

box((0,1.59,0),(.71,.57,.52),5,2,True)
ear(-.24);ear(.24)
box((0,1.15,-.006),(.74,.62,.46),3,0)
box((0,1.29,.25),(.30,.18,.05),3,1)
# status emblem as a 2 triangle quad in front of chest, not another 12-tri box
emit(5,[(-.105,1.36,.281),(.105,1.36,.281),(.085,1.23,.281),(-.085,1.23,.281)],(0,0,1),[(0,1),(1,1),(1,0),(0,0)],3)
box((0,.77,0),(.63,.27,.44),1,0)
# pack silhouette on back
box((0,1.13,-.31),(.45,.37,.18),3,1)
for side in (+1,-1):
 shoulder=6 if side==1 else 10;elbow=7 if side==1 else 11;wrist=8 if side==1 else 12
 hip=14 if side==1 else 17;knee=15 if side==1 else 18;ankle=16 if side==1 else 19
 box((side*.47,1.22,0),(.31,.26,.34),shoulder,0)
 box((side*.50,1.09,.07),(.22,.30,.25),shoulder,1)
 box((side*.54,.89,.22),(.23,.29,.25),elbow,0)
 box((side*.55,.70,.33),(.20,.17,.22),wrist,3)
 box((side*.20,.54,0),(.30,.35,.34),hip,0)
 box((side*.20,.29,0),(.28,.32,.32),knee,0)
 box((side*.20,.115,.11),(.31,.20,.43),ankle,3)
# Low-poly rifle seen by other players, owned by the Weapon joint. Mounted facing +Z.
box((-.18,1.05,.53),(.45,.17,.22),20,4)
box((-.18,1.04,.77),(.14,.12,.36),20,4)
box((-.18,.915,.50),(.12,.21,.17),20,1)

# Standard glTF 2.0 binary writer
blob=bytearray();bvs=[];acc=[]
def writebuffer(data,target=None):
 while len(blob)%4:blob.append(0)
 offset=len(blob);blob.extend(data);d={'buffer':0,'byteOffset':offset,'byteLength':len(data)}
 if target is not None:d['target']=target
 bvs.append(d);return len(bvs)-1

def accessor(values,dtype,ctype,itype,target=None, minmax=False):
 arr=np.asarray(values,dtype=dtype)
 idx=writebuffer(arr.tobytes(),target)
 out={'bufferView':idx,'byteOffset':0,'componentType':ctype,'count':len(arr),'type':itype}
 if minmax:
  if arr.ndim==1:out.update(min=[float(arr.min())],max=[float(arr.max())])
  else:out.update(min=arr.min(axis=0).astype(float).tolist(),max=arr.max(axis=0).astype(float).tolist())
 acc.append(out);return len(acc)-1

primitives=[]
for m,b in parts.items():
 if not b['idx']:continue
 pos=accessor(b['pos'],'<f4',5126,'VEC3',34962,True)
 nor=accessor(b['nor'],'<f4',5126,'VEC3',34962)
 uv=accessor(b['uv'],'<f4',5126,'VEC2',34962)
 j=accessor(b['j'],'<u2',5123,'VEC4',34962)
 w=accessor(b['w'],'<f4',5126,'VEC4',34962)
 ind=accessor(b['idx'],'<u2',5123,'SCALAR',34963)
 primitives.append({'attributes':{'POSITION':pos,'NORMAL':nor,'TEXCOORD_0':uv,'JOINTS_0':j,'WEIGHTS_0':w},'indices':ind,'material':m,'mode':4})

ibm=[]
for xyz in world:
 mat=np.eye(4,dtype=np.float32);mat[:3,3]=-xyz
 ibm.append(mat.flatten(order='F'))
ibmacc=accessor(ibm,'<f4',5126,'MAT4')

nodes=[]
for i,n in enumerate(names):
 node={'name':n,'translation':loc[i].tolist()}
 node['children']=[j for j,p in enumerate(parents) if p==i]
 nodes.append(node)
nodes.append({'name':'CatMarine_SkinnedMesh','mesh':0,'skin':0})

# Quaternion from XYZ Euler; used to keep movements subtle and Quake-esque.
def quat(x=0,y=0,z=0):
 cx,cy,cz=[math.cos(t*.5) for t in (x,y,z)];sx,sy,sz=[math.sin(t*.5) for t in (x,y,z)]
 return [sx*cy*cz-cx*sy*sz,cx*sy*cz+sx*cy*sz,cx*cy*sz-sx*sy*cz,cx*cy*cz+sx*sy*sz]

animations=[]
def clip(name,duration,tracks):
 sams=[];ch=[]
 for bone,frames in tracks.items():
  inp=accessor([t for t,rot in frames],'<f4',5126,'SCALAR',None,True)
  out=accessor([quat(*rot) for t,rot in frames],'<f4',5126,'VEC4')
  sams.append({'input':inp,'output':out,'interpolation':'LINEAR'})
  ch.append({'sampler':len(sams)-1,'target':{'node':bone,'path':'rotation'}})
 animations.append({'name':name,'samplers':sams,'channels':ch,'extras':{'durationSeconds':duration,'loop':name not in ['shoot','melee','hurt','death']}})

clip('idle',2.0,{
 3:[(0,(0,0,-.012)),(1,(0,0,.015)),(2,(0,0,-.012))],
 5:[(0,(0,-.015,0)),(1,(0,.015,0)),(2,(0,-.015,0))],
 6:[(0,(0,0,.025)),(1,(0,0,.0)),(2,(0,0,.025))],
 10:[(0,(0,0,-.025)),(1,(0,0,.0)),(2,(0,0,-.025))]})
clip('walk',.8,{
 14:[(0,(.35,0,0)),(.2,(0,0,0)),(.4,(-.35,0,0)),(.6,(0,0,0)),(.8,(.35,0,0))],
 17:[(0,(-.35,0,0)),(.2,(0,0,0)),(.4,(.35,0,0)),(.6,(0,0,0)),(.8,(-.35,0,0))],
 6:[(0,(-.21,0,0)),(.4,(.21,0,0)),(.8,(-.21,0,0))],
 10:[(0,(.21,0,0)),(.4,(-.21,0,0)),(.8,(.21,0,0))],
 15:[(0,(.07,0,0)),(.2,(.15,0,0)),(.4,(.04,0,0)),(.8,(.07,0,0))],
 18:[(0,(.04,0,0)),(.4,(.15,0,0)),(.6,(.05,0,0)),(.8,(.04,0,0))]})
clip('run',.57,{
 14:[(0,(.51,0,0)),(.285,(-.51,0,0)),(.57,(.51,0,0))],
 17:[(0,(-.51,0,0)),(.285,(.51,0,0)),(.57,(-.51,0,0))],
 6:[(0,(-.35,0,0)),(.285,(.35,0,0)),(.57,(-.35,0,0))],
 10:[(0,(.35,0,0)),(.285,(-.35,0,0)),(.57,(.35,0,0))],
 3:[(0,(.08,0,0)),(.285,(.11,0,0)),(.57,(.08,0,0))]})
clip('shoot',.18,{
 3:[(0,(0,0,0)),(.06,(-.06,0,0)),(.18,(0,0,0))],
 12:[(0,(0,0,0)),(.06,(-.10,0,0)),(.18,(0,0,0))],
 20:[(0,(0,0,0)),(.06,(-.12,0,0)),(.18,(0,0,0))]})
clip('melee',.42,{
 10:[(0,(0,0,0)),(.12,(-.45,0,-.10)),(.27,(.40,0,.12)),(.42,(0,0,0))],
 11:[(0,(0,0,0)),(.18,(-.35,0,0)),(.30,(.22,0,0)),(.42,(0,0,0))],
 3:[(0,(0,0,0)),(.2,(.12,0,-.08)),(.42,(0,0,0))]})
clip('hurt',.32,{
 3:[(0,(0,0,0)),(.09,(-.11,0,.08)),(.19,(-.04,0,-.03)),(.32,(0,0,0))],
 5:[(0,(0,0,0)),(.09,(.09,.06,0)),(.32,(0,0,0))]})
clip('death',.8,{
 0:[(0,(0,0,0)),(.3,(-.33,0,.14)),(.6,(-1.15,0,.13)),(.8,(-1.45,0,.11))],
 5:[(0,(0,0,0)),(.28,(.13,0,0)),(.8,(.21,0,0))],
 6:[(0,(0,0,0)),(.8,(.29,0,-.08))],
 10:[(0,(0,0,0)),(.8,(.29,0,.08))]})

jmat=[]
for m in materials.values():
 pbr={'baseColorFactor':m['color'],'metallicFactor':m['metallic'],'roughnessFactor':m['roughness']}
 if 'tex' in m:pbr['baseColorTexture']={'index':m['tex']}
 jmat.append({'name':m['name'],'pbrMetallicRoughness':pbr,'doubleSided':False,'emissiveFactor':m.get('emissive',[0,0,0])})
img_refs=[]
for nam,b in [('Cat_Face_256',tex_face),('Armor_Camo_256',tex_armor)]:
 bv=writebuffer(b);img_refs.append({'name':nam,'bufferView':bv,'mimeType':'image/png'})

model={
 'asset':{'version':'2.0','generator':'Cat Marine rigged reference-model builder 1.0'},
 'scene':0,'scenes':[{'name':'Cat Marine','nodes':[0,len(nodes)-1]}],
 'nodes':nodes,'skins':[{'name':'CatMarine_21_Joints','inverseBindMatrices':ibmacc,'skeleton':0,'joints':list(range(len(names)))}],
 'meshes':[{'name':'CatMarine_LowPoly','primitives':primitives,'extras':{'triangles':poly_count}}],
 'materials':jmat,'images':img_refs,'textures':[{'source':0},{'source':1}],
 'samplers':[{'magFilter':9728,'minFilter':9984,'wrapS':10497,'wrapT':10497}],
 'bufferViews':bvs,'accessors':acc,'buffers':[{'byteLength':len(blob)}],
 'animations':animations,
 'extras':{'game':'CAT ARENA: FERAL CLAW','coordinateSystem':'+Y-up +Z-forward','origin':'feet at y=0','thirdPersonOnly':True,
 'source':'Low-poly offline stand-in built from user-supplied reference. Not generated by Meshy.',
 'collision':'external cat_marine_hitboxes.json; use only third-person server/combat model'}
 }
for t in model['textures']:t['sampler']=0
# GLB binary length must match binary padding and buffer's byteLength can exclude trailing pad
json_str=json.dumps(model,separators=(',',':'),ensure_ascii=False).encode('utf-8')
while len(json_str)%4:json_str+=b' '
while len(blob)%4:blob.append(0)
size=12+8+len(json_str)+8+len(blob)
OUT.write_bytes(struct.pack('<4sII',b'glTF',2,size)+struct.pack('<I4s',len(json_str),b'JSON')+json_str+struct.pack('<I4s',len(blob),b'BIN\0')+blob)

hit={
 'character':'Cat Marine','version':1,'units':'model meters','axis':'+Y up, +Z forward',
 'sceneSource':'cat_marine_rigged.glb','height':2.08,'selfHitboxesEnabled':False,
 'boneIndex':{n:i for i,n in enumerate(names)},
 'boxes':[
  {'name':'head','bone':'Head','shape':'box','centerLocal':[0,0,0],'size':[.72,.60,.56],'damageMultiplier':2.0},
  {'name':'torso','bone':'Spine_02','shape':'box','centerLocal':[0,.08,0],'size':[.76,.74,.52],'damageMultiplier':1.0}],
 'capsules':[
  {'name':name,'fromBone':a,'toBone':b,'radius':r,'height':h,'damageMultiplier':1.0}
  for name,a,b,r,h in [('arm_L','Shoulder_L','Wrist_L',.18,.56),('arm_R','Shoulder_R','Wrist_R',.18,.56),
                      ('leg_L','Hip_L','Ankle_L',.22,.72),('leg_R','Hip_R','Ankle_R',.22,.72)]],
 'gameplay':{'thirdPersonRemoteOnly':True,'localPlayerModelVisibility':False,'preserveFirstPersonViewmodel':True,
             'cameraCollisionUsesExistingPlayerCapsule':True,'meleeHitboxActivation':'melee window controlled by game',
             'hurtboxes':True,'animatedJoints':True,'authoritativeServerHealth':'unchanged'},
 'animationClips':{'idle':{'loop':True},'walk':{'loop':True},'run':{'loop':True},
  'shoot':{'loop':False},'melee':{'loop':False},'hurt':{'loop':False},'death':{'loop':False}},
 'notes':'Hitbox descriptors are not automatic active collisions inside GLB. Bind these regions to animated bones in your game combat logic.'
}
(ROOT/'cat_marine_hitboxes.json').write_text(json.dumps(hit,indent=2))
(ROOT/'model_metadata.json').write_text(json.dumps({'triangles':poly_count,'bones':len(names),'animations':list(map(lambda a:a['name'],animations)),
 'meshes':1,'primitives':len(primitives),'textures':2,'sourceImage':'reference.png','meshFormat':'glTF 2.0 binary',
 'meshProvenance':'Procedural offline model from supplied reference. Meshy CLI unavailable.'},indent=2))
print(json.dumps({'output':str(OUT),'bytes':OUT.stat().st_size,'triangles':poly_count,'joints':len(names),'animations':[a['name'] for a in animations]},indent=2))
