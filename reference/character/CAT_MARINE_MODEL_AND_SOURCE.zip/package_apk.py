#!/usr/bin/env python3
"""Repackage the existing Android WebView APK with a patched single-file game.
Create fresh APK Signature Scheme v2 (RSA PKCS#1 v1.5 with SHA-256), for Android 7+.
The user will need to uninstall the differently signed earlier APK if upgrading in place.
"""
import io,zipfile,hashlib,struct,datetime
from pathlib import Path
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
R=Path(__file__).parent
SRC=R.parent/'game_base'/'CAT_ARENA_FERAL_CLAW_v0_17.apk'
HTML=R/'CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html'
OUT=R/'CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE.apk'
KEY=R/'cat_marine_debug_signing_key.pem'
# NOTE: this key is a throwaway per-build signing key. Keep for future updates; never
# claim installation can upgrade over an APK signed by someone else's different key.
if KEY.exists():
 key=serialization.load_pem_private_key(KEY.read_bytes(),password=None)
else:
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 KEY.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
 KEY.chmod(0o600)
sub=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'CAT ARENA LOCAL DEBUG')]);now=datetime.datetime.now(datetime.timezone.utc)
cert=(x509.CertificateBuilder().subject_name(sub).issuer_name(sub).public_key(key.public_key()).serial_number(x509.random_serial_number())
 .not_valid_before(now-datetime.timedelta(days=1)).not_valid_after(now+datetime.timedelta(days=3650)).sign(key,hashes.SHA256()))
cert_der=cert.public_bytes(serialization.Encoding.DER)
pub_der=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
# ZIP cleanly, maintaining the exact compiled manifest and dex from the original app.
outio=io.BytesIO()
with zipfile.ZipFile(SRC) as zin,zipfile.ZipFile(outio,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as zout:
 for old in zin.infolist():
  data=HTML.read_bytes() if old.filename=='assets/index.html' else zin.read(old.filename)
  info=zipfile.ZipInfo(filename=old.filename,date_time=old.date_time)
  info.compress_type=old.compress_type;info.external_attr=old.external_attr
  info.create_system=old.create_system
  zout.writestr(info,data,compress_type=old.compress_type,compresslevel=8)
unsigned=outio.getvalue();eocd=unsigned.rfind(b'PK\x05\x06')
if eocd<0:raise RuntimeError('no ZIP EOCD')
cd_off=struct.unpack_from('<I',unsigned,eocd+16)[0]
assert unsigned[cd_off:cd_off+4]==b'PK\x01\x02'
sections=(unsigned[:cd_off],unsigned[cd_off:eocd],unsigned[eocd:])
def chunk_digest(sections):
 dig=[];one=1024*1024
 for s in sections:
  for i in range(0,len(s),one):
   chunk=s[i:i+one];dig.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(chunk))+chunk).digest())
 return hashlib.sha256(b'\x5a'+struct.pack('<I',len(dig))+b''.join(dig)).digest()
digest=chunk_digest(sections)
def lp(b):return struct.pack('<I',len(b))+b
alg=0x0103  # RSASSA-PKCS1-v1_5 with SHA-256 digest
rec=struct.pack('<I',alg)+lp(digest)
signed=lp(lp(rec))+lp(lp(cert_der))+lp(b'')
sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
key.public_key().verify(sig,signed,padding.PKCS1v15(),hashes.SHA256())
signer=lp(signed)+lp(lp(struct.pack('<I',alg)+lp(sig)))+lp(pub_der)
v2=lp(lp(signer))
pair=struct.pack('<Q',len(v2)+4)+struct.pack('<I',0x7109871a)+v2
size=len(pair)+24
sig_block=struct.pack('<Q',size)+pair+struct.pack('<Q',size)+b'APK Sig Block 42'
assert len(sig_block)==size+8
# Patch EOCD's central-directory offset after the inserted signature block.
eocd_rest=bytearray(unsigned[eocd:]);struct.pack_into('<I',eocd_rest,16,cd_off+len(sig_block))
signed_apk=unsigned[:cd_off]+sig_block+unsigned[cd_off:eocd]+eocd_rest
OUT.write_bytes(signed_apk)
# Independent structural readback and digest/signature verification.
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 assert z.read('assets/index.html')==HTML.read_bytes()
 assert z.read('classes.dex')==zipfile.ZipFile(SRC).read('classes.dex')
recovered=OUT.read_bytes();new_eocd=recovered.rfind(b'PK\x05\x06');new_off=struct.unpack_from('<I',recovered,new_eocd+16)[0]
assert new_off==cd_off+len(sig_block)
assert recovered[new_off-len(sig_block)+len(sig_block)-16:new_off]==b'APK Sig Block 42'
normalized=bytearray(recovered[new_eocd:]);struct.pack_into('<I',normalized,16,cd_off)
assert chunk_digest((recovered[:cd_off],recovered[new_off:new_eocd],bytes(normalized)))==digest
print(f'APK: {OUT}\nsize: {OUT.stat().st_size}\nformat: ZIP with APK Signature Scheme v2\nverified: ZIP payload, SHA256 chunk digest, 2048-bit RSA signature\ncentral directory: {new_off}, signer block length: {len(sig_block)}')
