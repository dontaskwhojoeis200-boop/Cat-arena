CAT ARENA: FERAL CLAW | CAT MARINE PLAYER UPDATE
Version: v0.17-CAT-MARINE (based on user-uploaded v0.17 APK)

CONTENTS
- CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE.apk: modified, offline-signed Android game
- CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html: same patched game as standalone HTML
- cat_marine_rigged.glb: actual glTF 2.0 skinned character, 274 triangles, 21 joints
- cat_marine_hitboxes.json: 2 boxes + 4 capsules; metadata/authoring coordinates
- cat_marine_preview.png: offline rendered front / three-quarter / side model preview
- build_cat_marine.py and integrate_v17.py: reproducible generation + integration
- armor_camo_256.png / cat_face_256.png: 256px maps embedded in the GLB

IMPLEMENTED IN PLAYABLE GAME
- Reference-based 274-triangle third-person marine using existing WebGL2 renderer.
- Existing GPU 16-parameter skeletal animation system for locomotion; brief shoot/hurt overlays.
- Remote player model shown to other players. Own first-person weapons remain untouched.
- Six-part collision approximation using rotated AABBs for head, torso, arms and legs;
  shot sweeping tested against those volumes for enemy projectiles targeting remote players.
- GLB exports seven clips: idle, walk, run, shoot, melee, hurt, death.
- Runtime debug functions: VOID_CAT(), VOID_MARINE_HITBOXES(), VOID_MARINE_FORCE_ANIM(id,clip).

IMPORTANT LIMITATIONS
- The Meshy plugin CLI was not reachable (npm DNS failure), so the model was built procedurally
  using the supplied reference image instead. Do not claim Meshy generated this mesh.
- The GLB's rig/animation are a genuine glTF skin and seven curves; in-game rendering repacks
  it into the engine's existing 16-pose-slot WebGL2 pipeline (not a general GLB animation mixer).
- Hitboxes in-game use conservative per-part axis-aligned bounds for a yawed model;
  the JSON's capsules remain authoring metadata, not exact swept capsule physics.
- This game patch does not alter the server's authoritative damage/netcode.
- Not tested by actually installing on Android hardware. APK payload, v2 signature and JavaScript
  syntax were checked in the build environment.
- APK signed with a new temporary local signing certificate. Because the existing v0.17 APK was
  signed by a different key, uninstall the old installation before installing this one. Back up
  any locally saved settings/data first. In-place upgrade may fail with a signature error.
- Later v0.18 music/build changes are NOT included. This is intentionally a v0.17-based patch,
  not an update of the inaccessible v0.18 package.

INSTALL
1. Back up local data if needed, uninstall prior differently signed Cat Arena installation.
2. Install the included APK and grant Android's one-time install-from-source permission if prompted.
3. In multiplayer, remote clients must use the same update to see this locally rendered model.
4. Existing server APIs are unchanged; the model is a client-side rendering/gameplay presentation update.
