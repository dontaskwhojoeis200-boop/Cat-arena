#!/usr/bin/env python3
"""Port the reference GLB's 274 rigid skinned triangles into CAT ARENA v0.17's WebGL2 instanced GPU skeleton.
The packed GLB is retained separately for full glTF skin/animation use. Gameplay uses the
existing renderer's bone tags and 16-value pose shader, without changing the first-person gun.
"""
import json,base64,struct,re,math,io
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).parent;S=R.parent/'game_base'/'v17_unpacked'/'assets'/'index.html';O=R/'CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html'
glb=(R/'cat_marine_rigged.glb').read_bytes();n=struct.unpack_from('<I',glb,12)[0];g=json.loads(glb[20:20+n]);pos=20+n;blen=struct.unpack_from('<I',glb,pos)[0];d=memoryview(glb)[pos+8:pos+8+blen]
def a(index):
 ac=g['accessors'][index];v=g['bufferViews'][ac['bufferView']];dt={5126:'<f4',5123:'<u2',5125:'<u4'}[ac['componentType']];c={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[ac['type']]
 off=v['byteOffset']+ac.get('byteOffset',0)
 return np.frombuffer(d[off:off+ac['count']*c*np.dtype(dt).itemsize],dtype=dt).reshape(-1,c)
# Preserve single flat triangle primitive encoding the game's entity renderer expects.
armor=np.asarray(Image.open(R/'armor_camo_256.png').convert('RGB'))
colors={1:[.20,.23,.16],2:[.63,.35,.20],3:[.31,.26,.20],4:[.24,.23,.21],5:[1.0,.19,.63],6:[1,1,1]}
vtx=[]
for pr in g['meshes'][0]['primitives']:
 mat=pr['material'];A=pr['attributes'];vs=a(A['POSITION']);ns=a(A['NORMAL']);uv=a(A['TEXCOORD_0']);joint=a(A['JOINTS_0'])[:,0];indices=a(pr['indices']).flatten().reshape(-1,3)
 for ix in indices:
  # Convert a Y-up GLB with +Z facing to the engine's Z-up model with +Y facing.
  # Orientation reversal is corrected by reversing triangle winding here.
  order=[int(ix[0]),int(ix[2]),int(ix[1])]
  bone=int(joint[order[0]])
  # GPU skeleton tag: left at negative X. Generic polygon shoulder/hip/elbow chains.
  if bone in (14,15,16,17,18,19): group=2 if bone in (14,15,16) else 1
  elif bone in (6,7,8,9,10,11,12,13,20):group=4 if bone in (6,7,8,9) else 3
  else:group=0
  material=(20.0 if mat==6 else 0.0)+group*.04
  q=colors.get(mat)
  if mat==0:
   UV=uv[order].mean(axis=0);px=int(UV[0]*255)%256;py=int(UV[1]*255)%256
   q=(armor[py,px].astype(float)/255*.94).tolist()
  for k in order:
   p=vs[k];N=ns[k];u=uv[k]
   # Flip glTF V so the shader's baked five-cell face atlas is upright.
   # Keep UVs clamped away from silhouette edges for fewer filtering artifacts.
   vtx.extend([float(p[0]),float(p[2]),float(p[1]),float(N[0]),float(N[2]),float(N[1]),
               *[float(v) for v in q],float(u[0]),float(1-u[1]),material])
arr=np.asarray(vtx,dtype='<f4');count=arr.size//36
assert count==274,(count,len(arr))
encoded=base64.b64encode(arr.tobytes()).decode('ascii')

html=S.read_text()
pattern=r'function buildMarineCat\(\)\{.*?\n\}\nconst marineCatMesh=' # match non-greedy one function
replacement='''// v0.17-CAT-MARINE: reference-based model embedded from cat_marine_rigged.glb.
// Same pre-existing WebGL2 GPU skinning path, not the first-person gun shader.
const CAT_MARINE_REFERENCE={triangles:274,joints:21,animationStates:['idle','walk','run','shoot','melee','hurt','death'],
 hitboxParts:['head','torso','arm_L','arm_R','leg_L','leg_R'],source:'user character rig sheet'};
function buildMarineCat(){
 const b=atob('''+json.dumps(encoded)+'''),u=new Uint8Array(b.length);
 for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);
 return new Float32Array(u.buffer);
}
const marineCatMesh='''
html,nsub=re.subn(pattern,lambda m:replacement,html,1,flags=re.S);assert nsub==1,nsub
# Remove the old auto-bone classification. Our mesh is authored with per-triangle bone groups already.
old_pattern=r" // Reuse the same rigid-component method for remote player avatars\.\n // Whole triangles are classified once at startup: no vertex stretching\.\n for\(let i=0;i<data\.length;i\+=36\)\{.*?\n \}\n"
html,nn=re.subn(old_pattern,' // Rig groups come from the 21-joint reference skeleton.\n',html,count=1,flags=re.S)
assert nn==1,nn
# Match the model's real pivot positions in the existing GPU kneebend/elbow pose code.
old="const MARINE_RIG={type:'marine',height:1.36,hip:.57,knee:.29,shoulder:1.12,elbow:.86,neck:1.2,spine:.75,shoulderX:.28,wingRoot:1,wingTip:1,depth:.4,width:.45,cls:'soldier',attack:'shoot'};"
new="const MARINE_RIG={type:'marine',height:2.08,hip:.69,knee:.37,shoulder:1.21,elbow:.95,neck:1.28,spine:1.09,shoulderX:.47,wingRoot:1,wingTip:1,depth:.52,width:.38,cls:'soldier',attack:'shoot'};"
assert old in html;html=html.replace(old,new,1)
# All animations intended to be understated. The current engine already computes
# walk/run/idle pose in enemyEvalPose() and does rigid child motion on the GPU.
old='''if(p._poseFrame!==renderFrameId){enemyEvalPose(p,MARINE_RIG,pose,now,0);p._poseFrame=renderFrameId;}marinePoses.set(pose,n*16);n++}'''
new='''if(p._poseFrame!==renderFrameId){
    enemyEvalPose(p,MARINE_RIG,pose,now,0);
    const shoot=Math.max(0,Math.min(1,((p._marineShootUntil||0)-now)/.14));
    const melee=Math.max(0,Math.min(1,((p._marineMeleeUntil||0)-now)/.42));
    const hurt=Math.max(0,Math.min(1,((p._marineHurtUntil||0)-now)/.27));
    if(shoot){pose[5]+=.08*shoot;pose[7]+=.06*shoot;pose[10]-=.055*shoot;}
    if(melee){pose[5]+=.22*melee;pose[7]-=.17*melee;pose[11]+=.07*melee;}
    if(hurt){pose[10]-=.12*hurt;pose[12]+=.08*hurt;}
    if(p.downed){pose.fill(0);pose[15]=-.84;pose[2]=-.25;pose[3]=-.23;pose[12]=-.12;}
    p._poseFrame=renderFrameId;
  }marinePoses.set(pose,n*16);n++}'''
assert old in html;html=html.replace(old,new,1)
# Hide locally outside the existing mirror, where the camera is positioned outside the body.
# The first person viewmodel render function remains untouched.
# Hitboxes for other marines follow source dimensions. Keep physics capsule unchanged.
needle='''function pointBoxDistance(x,y,z,b){'''
insert='''// CAT-MARINE reference 6-region enemy-projectile hit layout.
// AABBs enclose rotated limb regions. Movement still uses PLAYER_RADIUS/HEIGHT;
// the FP camera and first-person gun never reference these 3rd-person volumes.
function marineHitBoxes(p){
 const a=(Number.isFinite(p.a)?p.a:0)-Math.PI/2,c=Math.cos(a),s=Math.sin(a),Z=Number.isFinite(p.z)?p.z:0;
 function part(name,cx,cy,cz,sx,sy,sz){
  const ox=c*cx-s*cy,oy=s*cx+c*cy;
  const hx=(Math.abs(c)*sx+Math.abs(s)*sy)*.5;
  const hy=(Math.abs(s)*sx+Math.abs(c)*sy)*.5;
  return {part:name,x0:p.x+ox-hx,x1:p.x+ox+hx,y0:p.y+oy-hy,y1:p.y+oy+hy,
   z0:Z+cz-sz*.5,z1:Z+cz+sz*.5};
 }
 return [part('head',0,0,1.59,.72,.56,.60),part('torso',0,0,1.16,.76,.52,.74),
  part('arm_L',-.51,.11,.97,.36,.57,.62),part('arm_R',.51,.11,.97,.36,.57,.62),
  part('leg_L',-.20,.04,.45,.44,.48,.90),part('leg_R',.20,.04,.45,.44,.48,.90)];
}
function marineShotTime(ax,ay,az,bx,by,bz,p,r=0){
 let best=null,part='body';for(const b of marineHitBoxes(p)){
  const t=segmentBoxTime(ax,ay,az,bx,by,bz,b,r);
  if(t!==null&&(best===null||t<best)){best=t;part=b.part;}
 }return {t:best,part};
}
'''
assert needle in html;html=html.replace(needle,insert+needle,1)
# Wire combat/projectile collision to animated appearance proportions, only for remote players.
old=''' const hitTime=segmentBoxTime(s.x,s.y,s.z,nx,ny,nz,body,shotRadius);'''
new="""  const hitTime=s.targetId&&target?marineShotTime(s.x,s.y,s.z,nx,ny,nz,target,shotRadius).t:
      segmentBoxTime(s.x,s.y,s.z,nx,ny,nz,body,shotRadius);"""
assert old in html;html=html.replace(old,new,1)
# One-shot audio broadcasts are the existing net traffic, no new messages/protocol.
old='''  if(shooter&&typeof WFX!==\'undefined\')WFX.remoteFire(weapon,shooter);'''
new="""   if(shooter){shooter._marineShootUntil=now+.14;
    if(typeof WFX!=='undefined')WFX.remoteFire(weapon,shooter);}"""
assert old in html;html=html.replace(old,new,1)
old=''' const w=WEAPONS[i];if(now<(p.nextFire||0))return;'''
new="""  const w=WEAPONS[i];if(now<(p.nextFire||0))return;
  p._marineShootUntil=now+.14;"""
assert old in html;html=html.replace(old,new,1)
old=""" p.hp=Math.max(0,p.hp-Math.max(0,Number(damage)||0));"""
new="""  p.hp=Math.max(0,p.hp-Math.max(0,Number(damage)||0));
  p._marineHurtUntil=now+.27;"""
assert old in html;html=html.replace(old,new,1)
# Public diagnostics, no gameplay effect.
old="window.VOID_CAT=()=>({model:'armored marine cat',triangles:marineCatMesh.count/3,firstPersonOnly:true,motionPercent:Math.round(motionIntensity*100)});"
new="""window.VOID_CAT=()=>({model:'CAT MARINE reference-based player',triangles:marineCatMesh.count/3,
 thirdPersonOnly:true,firstPersonViewmodelPreserved:true,sourceJointCount:21,
 runtimePoseSlots:16,hitboxes:6,animations:CAT_MARINE_REFERENCE.animationStates,
 motionPercent:Math.round(motionIntensity*100)});
window.VOID_MARINE_HITBOXES=()=>[...netPlayers.values()].map(p=>({id:p.netId,parts:marineHitBoxes(p)}));
window.VOID_MARINE_FORCE_ANIM=(id,clip)=>{const p=netPlayers.get(id);if(!p)return false;
 const map={shoot:'_marineShootUntil',melee:'_marineMeleeUntil',hurt:'_marineHurtUntil'};
 if(!map[clip])return false;p[map[clip]]=now+(clip==='melee'?.42:.25);return true;};"""
assert old in html;html=html.replace(old,new,1)
# Update HTML version string in game UI telemetry only, preserve everything else.
html=html.replace('FERAL CLAW v0.17: grayscale outlined UI','FERAL CLAW v0.17-CAT-MARINE: grayscale outlined UI')
O.write_text(html)
print(json.dumps({'playable_html':str(O),'html_bytes':O.stat().st_size,'triangles':count,'packed_model_byte_len':arr.nbytes,'first_person_shader_unchanged':True,'hitbox_parts':6},indent=2))
