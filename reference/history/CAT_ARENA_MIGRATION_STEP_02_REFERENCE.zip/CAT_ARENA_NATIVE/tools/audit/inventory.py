"""Read-only inventory of the preserved reference. No game execution or conversion."""
from pathlib import Path
import json,re,hashlib,zipfile,struct
R=Path(__file__).resolve().parents[2]; E=R/'docs/evidence'
def sha(b):return hashlib.sha256(b).hexdigest()
files=[];archives={}
for base in ('legacy_web','reference'):
 for p in sorted((R/base).rglob('*')):
  if not p.is_file():continue
  b=p.read_bytes();files.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
  if p.suffix in ('.zip','.apk'):
   with zipfile.ZipFile(p) as z:
    archives[p.name]={'crc_ok':z.testzip() is None,'entries':[{'path':n.filename,'bytes':n.file_size,'sha256':sha(z.read(n))} for n in z.infolist() if not n.is_dir()]}
s=(R/'legacy_web/index.html').read_text();blocks=[]
for i,m in enumerate(re.finditer(r'<script\b[^>]*>(.*?)</script>',s,re.S),1):
 body=m.group(1);comment=re.match(r'\s*/\*([^*]+)\*/',body)
 label=comment.group(1).strip() if comment else ('helios map module' if i==26 else 'helios baked lightmaps' if i==27 else 'presentation interaction')
 blocks.append({'script':i,'label':label,'html_start_line':s[:m.start()].count('\n')+1,'html_end_line':s[:m.end()].count('\n')+1,'bytes':len(body.encode()),'sha256':sha(body.encode())})
with zipfile.ZipFile(R/'reference/CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE.apk') as z:
 apkmatch=z.read('assets/index.html')==(R/'legacy_web/index.html').read_bytes()
with zipfile.ZipFile(R/'reference/CAT_MARINE_MODEL_AND_SOURCE.zip') as z:
 b=z.read('cat_marine_rigged.glb');magic,ver,length=struct.unpack_from('<III',b);n,t=struct.unpack_from('<II',b,12);g=json.loads(b[20:20+n])
 glb={'version':ver,'declared_length':length,'actual_length':len(b),'meshes':len(g.get('meshes',[])),'primitives':sum(len(m['primitives']) for m in g['meshes']),'triangles':sum(g['accessors'][p['indices']]['count']//3 for m in g['meshes'] for p in m['primitives']),'skin_joint_counts':[len(x['joints']) for x in g.get('skins',[])],'animations':[x.get('name') for x in g.get('animations',[])],'images':len(g.get('images',[]))}
# Top-level-looking declarations are leads for manual scope review, not a dead-code proof.
decls={}
for i,l in enumerate(s.splitlines(),1):
 m=re.match(r'function\s+(\w+)\s*\(',l)
 if m:decls.setdefault(m[1],[]).append(i)
duplicates={k:v for k,v in decls.items() if len(v)>1}
E.mkdir(parents=True,exist_ok=True)
for name,data in [('SOURCE_HASHES.json',files),('ARCHIVE_INVENTORY.json',archives),('SCRIPT_INDEX.json',blocks),('STATIC_CHECKS.json',{'apk_html_matches':apkmatch,'glb':glb,'duplicate_declaration_candidates':duplicates})]:
 (E/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'files':len(files),'scripts':len(blocks),'archives':len(archives),'apk_html_matches':apkmatch,'glb':glb,'duplicate_declaration_candidates':duplicates},indent=2))
