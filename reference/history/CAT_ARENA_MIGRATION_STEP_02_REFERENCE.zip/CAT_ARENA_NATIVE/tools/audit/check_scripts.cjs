'use strict';
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.resolve(__dirname,'../..');
const files=['legacy_web/index.html','reference/CAT_ARENA_FERAL_CLAW_v0_18_SOUND_BREAK_PLAYABLE.html'];
let failed=false;const results=[];
for(const file of files){
 const html=fs.readFileSync(path.join(root,file),'utf8');
 const scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)];
 let passed=0;const errors=[];
 for(let i=0;i<scripts.length;i++)try{new vm.Script(scripts[i][1],{filename:`${file}:script-${i+1}`});passed++;}catch(e){errors.push(String(e));failed=true;}
 try{new vm.Script(scripts.map(m=>m[1]).join('\n'),{filename:file+':combined'});}catch(e){errors.push(String(e));failed=true;}
 results.push({file,scripts:scripts.length,parsed:passed,combined_parse:errors.length===0,errors});
}
console.log(JSON.stringify({node:process.version,method:'V8 syntax compilation only; no script execution, DOM, WebGL, or gameplay verification',results},null,2));
process.exitCode=failed?1:0;
