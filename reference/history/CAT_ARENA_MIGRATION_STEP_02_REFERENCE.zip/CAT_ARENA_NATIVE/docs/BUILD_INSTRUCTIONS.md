# Build and inspection instructions

## This checkpoint

No native application exists yet. There are no CMake targets or native compiler results. Do not run invented Windows or Android commands. Step 09 and Step 10 will establish those workflows.

From the CAT_ARENA_NATIVE directory, with Python 3 and Node available:

```sh
python3 tools/audit/inventory.py
node tools/audit/check_scripts.cjs
```

Inventory regenerates JSON evidence for preserved files/archive members and GLB metadata. JavaScript check uses V8 compilation without executing game code, both per-script and concatenated. It is not a WebGL shader compiler or gameplay smoke test.

Verify source bytes against the checkpoint hashes before regenerating evidence:

```sh
python3 - <<'PYVERIFY'
import hashlib,json
from pathlib import Path
for f in json.loads(Path('docs/evidence/SOURCE_HASHES.json').read_text()):
    data=Path(f['path']).read_bytes()
    assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'], f['path']
print('Preserved source hashes match')
PYVERIFY
```

## Legacy browser reference — commands provided, not executed in Step 01

```sh
python3 -m http.server 8000 --directory legacy_web
```

Open `http://localhost:8000/index.html?map=helios-crucible` in a WebGL2-capable browser. Other keys: bastion-keep, reactor-bastion, q3-gallery. The HTML is standalone; HTTP hosting avoids local-file browser differences. Start through the real menu/gesture gate. A simple static HTTP server does not supply /rooms or /ws.

For Step 02 record browser/GPU/driver, map and source SHA, render resolution, DPR, all quality/AA/texture/light/visibility settings, adaptive resolution off for comparisons, fixed camera/input scene, enemy count, warmup and sampling duration. Capture actual output; no benchmark has been performed here.

## Multiplayer reference

Current matching relay build/package/lock remains missing. Historical server archives use Node/ws, but the modular staging server rejects current build/map IDs and v3.24 has an older contract. Do not publish or patch a relay just to make a Step 01 audit appear complete. Obtain the deployed server source/configuration and validate its handshake in Step 02/27.

## Historical Android workflow and limitations

v0.15 README prescribes `python3 work/build_native.py`, `python3 work/package_apk.py`, `python3 work/verify_apk.py` from its extracted archive. These are historical Python wrapper/packaging commands with path and signing assumptions; they are not verified current build commands. Read the actual scripts before running them. The model archive's package_apk.py expects a separate game_base source APK; integrate_v17.py expects its unpacked HTML; build_cat_marine.py expects reference.png. Exact original Cat Marine signing key is not supplied. Do not claim a reproducible same-signer current APK rebuild from these files.

## Required native configurations

| Configuration | Status | Build command |
|---|---|---|
| Windows Debug | NOT_STARTED | Defined in Step 09/31 |
| Windows Release | NOT_STARTED | Defined in Step 09/31 |
| Android ARM64 Debug | NOT_STARTED | Defined in Step 10 |
| Android ARM64 Release | NOT_STARTED | Defined in Step 10/32 |
| Linux native | NOT_STARTED | Defined when foundation supports it |

APK signing, installation, Android lifecycle, Vulkan validation and platform compilation were not executed during this audit. The existing reference APK is included unchanged, not offered as a new native build.

## Step 02 reference capture

Follow BASELINE_REPORT.md for the pinned browser configuration, capture commands and relay test. The original HTML needs no compilation; source capture tools are separate from game dependencies. Native Windows Debug/Release and Android ARM64 Debug/Release remain NOT_STARTED. No new platform binary is claimed. The new v0.18 build project is preserved unapplied and unbuilt.
