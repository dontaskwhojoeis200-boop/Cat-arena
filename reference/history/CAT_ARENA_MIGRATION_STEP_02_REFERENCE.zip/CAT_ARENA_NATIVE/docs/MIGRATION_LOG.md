# Migration log

## 2026-11-08 — migration-0.1-audit

Phase 0 / Step 01 completed as a static source audit. Located newest Cat Marine HTML/APK and supporting source artifacts. Selected the newest artifact by timestamp as audit reference and preserved the v0.18 music branch separately. No merge or game changes.

Created SOURCE_AUDIT with source locations, complete inline module inventory, dependency diagram, complexity ratings, numerical behavior anchors, Android packaging findings and explicit missing materials. Created continuity documents, reproducible static inventory/syntax tools and evidence. Native implementations remain NOT_STARTED. Current server compatibility, original asset regeneration, signing continuity and runtime behavior remain unverified or blocked by inputs.

Verified two HTMLs (55 scripts each plus combined syntax), five archive CRCs, APK/HTML equality and GLB structure. No runtime/GPU/device/benchmark execution. Prior README test claims are not adopted as present results.

Next: Step 02 reference build only upon command. Preserve this checkpoint and resolve matching relay/build inputs as needed; single-player reference testing can proceed independently.

## 2026-11-09 — Step 02 / migration-0.2-reference-blocked

Preserved the Step 01 report in history. Added pinned reference config, proposed browser capture driver, environment/failure evidence and BASELINE_REPORT.md. Runtime attempts blocked before game execution; no screenshots or benchmarks. Inspected newly available v0.18 patch/build project (unapplied) and v0.17 relay package; relay HTML exactly matches the reference. Preserved archives and restored expected test layout. Supplied mock relay test passed; real multiplayer remains unverified. Original eight source hashes unchanged. Step 02 remains BLOCKED; no subsequent step implemented.
