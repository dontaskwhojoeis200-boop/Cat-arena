# Porting status

Checkpoint: migration-0.2-reference-blocked. COMPLETE below describes the audit, not a port.

| Module/work item | Status | Evidence / next dependency |
|---|---|---|
| Step 01 source-location audit | COMPLETE | SOURCE_AUDIT.md |
| Source preservation/static inventory | TESTED | evidence/SOURCE_HASHES.json, ARCHIVE_INVENTORY.json |
| Legacy JS syntax | TESTED | evidence/SYNTAX_CHECKS.json; not runtime |
| Step 02 reference runtime | BLOCKED | BASELINE_REPORT.md; no successful game execution |
| Reference capture driver/configuration | IMPLEMENTED | Syntax checked only; runtime validation pending |
| Current relay mock smoke test | TESTED | Mock sockets and local HTTP only; no live gameplay |
| Current relay provenance | COMPLETE | Matching build relay found in additional v0.17 package; see baseline report |
| Exact original asset regeneration | BLOCKED | Missing current bake/import/bundle tools and marine reference input |
| Current APK same-signer rebuild | BLOCKED | Cat Marine original signing key unavailable in inspected model ZIP |
| Native platform/input/application | NOT_STARTED | Step 09 onward |
| Native Vulkan/render/resources/materials | NOT_STARTED | Steps 11–19 |
| Native world/assets/collision | NOT_STARTED | Export and parity prerequisites |
| Native movement/weapons/AI/waves | NOT_STARTED | Reference fixtures and core simulation |
| Native animation/hitboxes | NOT_STARTED | Preserve procedural runtime versus GLB distinction |
| Native audio/music | NOT_STARTED | Resolve branch and asset provenance |
| Native multiplayer | NOT_STARTED | Current protocol/server analysis and test sessions |
| Native UI/HUD/settings | NOT_STARTED | Native rendering and platform integration |
| Windows Debug / Release | NOT_STARTED | No native build targets |
| Android ARM64 Debug / Release | NOT_STARTED | No native build targets |
| Linux native | NOT_STARTED | No native build targets |
| Native optimization and release parity | NOT_STARTED | Requires executable reference and native builds |

Allowed statuses: NOT_STARTED, IN_PROGRESS, IMPLEMENTED, COMPILED, TESTED, BLOCKED, COMPLETE. No native module may inherit the legacy syntax-test status.
