#!/usr/bin/env python3
"""Apply Cat Arena 0.17 mouse/input and settings hotfix without rewriting game assets.

Usage: python patch_game.py CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html
Output: game/index.html and android/app/src/main/assets/index.html
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

CSS = r'''
/* CAT ARENA v0.18 - keyboard/mouse settings accessibility fix */
#fovPanel.open {
  display:flex!important;flex-direction:column!important;overflow:hidden!important;
  width:min(640px,calc(100dvw - 16px))!important;
  max-height:calc(100dvh - 12px)!important;
}
#fovPanel .panelhead {flex:0 0 auto!important;}
#fovPanel .settingsTabs {
  display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;
  gap:5px!important;flex:0 0 auto!important;overflow:visible!important;
  padding:8px!important;
}
#fovPanel .settingsTabs .tabbtn {
  min-width:0!important;min-height:38px!important;white-space:normal!important;
  font-size:11px!important;padding:7px 3px!important;cursor:pointer!important;
}
#fovPanel .settingsBody {
  flex:1 1 auto!important;min-height:0!important;max-height:none!important;
  overflow-y:auto!important;overflow-x:hidden!important;
  overscroll-behavior:contain!important;touch-action:pan-y!important;scrollbar-width:auto!important;
}
#fovPanel .settingsBody::-webkit-scrollbar {width:12px;}
#fovPanel .settingsBody::-webkit-scrollbar-thumb {
  background:#777e86;border:2px solid #151619;
}
#fovPanel #settingsResume {
  flex:0 0 auto!important;position:static!important;margin:7px 12px 10px!important;
}
@media(max-width:490px) {
  #fovPanel .settingsTabs {grid-template-columns:repeat(2,minmax(0,1fr))!important;}
  #fovPanel .tabbtn {font-size:10px!important;min-height:32px!important;}
}
'''

JS = r'''
(function(){
  'use strict';
  window.catNativeMouseCaptured = false;
  window.catExternalMouseDetected = window.catExternalMouseDetected || false;
  window.catNativeCaptureChanged = function(captured) {
    window.catNativeMouseCaptured = !!captured;
    if (captured && typeof noteInput === 'function') noteInput('kbm');
    if (typeof updateMouseStatus === 'function') updateMouseStatus();
  };
  window.catNativeMouseMove = function(dx,dy) {
    if(!Number.isFinite(dx)||!Number.isFinite(dy)) return;
    window.catExternalMouseDetected = true;
    if(typeof noteInput === 'function') noteInput('kbm');
    if(typeof active !== 'undefined' && active && !fovPanelOpen && !voidPauseOpen && typeof aim==='function') aim(dx,dy);
  };
  window.catNativeMouseButton = function(pressed) {
    if(typeof active==='undefined'||!active||fovPanelOpen||voidPauseOpen) return;
    if(typeof fireHeld==='undefined') return;
    fireHeld=!!pressed;
    if(pressed && typeof fireWeapon==='function') fireWeapon();
  };
  const panel = document.getElementById('fovPanel');
  if (!panel) return;
  const tabs = Array.from(panel.querySelectorAll('.settingsTabs [role="tab"]'));
  panel.addEventListener('keydown', function(e) {
    const atTab=tabs.indexOf(e.target);
    if(atTab!==-1 && ['ArrowLeft','ArrowRight','Home','End'].includes(e.key)) {
      e.preventDefault();e.stopPropagation();
      const next=e.key==='Home'?0:e.key==='End'?tabs.length-1:
        (atTab+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
      tabs[next].focus();tabs[next].click();
    } else if((e.ctrlKey&&e.key==='Tab')||e.key==='PageDown'||e.key==='PageUp') {
      if(e.target.matches('input,select,textarea')) return;
      e.preventDefault();e.stopPropagation();
      const cur=Math.max(0,tabs.findIndex(t=>t.classList.contains('selected')));
      const dir=e.key==='PageUp'||e.shiftKey?-1:1;
      const next=(cur+dir+tabs.length)%tabs.length;
      tabs[next].focus();tabs[next].click();
    }
  });
  window.addEventListener('keydown', e=>{
    if(e.key==='Escape' && window.catNativeMouseCaptured)
      window.AndroidBridge?.releaseMouseCapture?.();
  },true);
})();
'''

def replace_once(s, original, replacement, label):
    count = s.count(original)
    if count != 1:
        raise RuntimeError(f'{label}: expected once, found {count}. This is not the expected v0.17 HTML; refusing risky patch.')
    return s.replace(original, replacement, 1)

def patch_html(s):
    if 'id="cat-mouse-settings-hotfix"' in s:
        raise RuntimeError('Hotfix already applied. Use the original v0.17 HTML.')
    if 'CAT ARENA' not in s.upper() or 'id="fovPanel"' not in s:
        raise RuntimeError('Input does not look like the expected Cat Arena game.')
    s = replace_once(s,
        'function lockedMouse(){return document.pointerLockElement===canvas}',
        'function lockedMouse(){return document.pointerLockElement===canvas||window.catNativeMouseCaptured===true}',
        'mouse-lock recognition')
    s = replace_once(s,
        'if(!active||lockedMouse()||fovPanelOpen||isTouchMode())return;',
        """if(!active||lockedMouse()||fovPanelOpen)return;
 if(window.AndroidBridge&&window.catExternalMouseDetected){
  noteInput('kbm');lockFailure='REQUESTING NATIVE MOUSE CAPTURE';updateMouseStatus();
  window.AndroidBridge.requestMouseCapture();return;
 }
 if(isTouchMode())return;""",
        'Android/DeX pointer capture')
    s = replace_once(s,
        'if(fovPanelOpen&&document.pointerLockElement===canvas)document.exitPointerLock();updateMouseStatus()',
        '''if(fovPanelOpen&&document.pointerLockElement===canvas)document.exitPointerLock();
 if(fovPanelOpen&&window.catNativeMouseCaptured)window.AndroidBridge?.releaseMouseCapture?.();
 updateMouseStatus()''',
        'settings releases pointer capture')
    s = replace_once(s,
        "if(e.pointerType==='touch')noteInput('touch');else if(e.pointerType==='mouse')noteInput('kbm');",
        "if(e.pointerType==='touch')noteInput('touch');else if(e.pointerType==='mouse'){window.catExternalMouseDetected=true;noteInput('kbm');}",
        'external mouse input detection')
    s = replace_once(s,
        'if(lockedMouse()){aim(e.movementX||0,e.movementY||0);return}',
        '''if(fovPanelOpen||voidPauseOpen||window.catNativeMouseCaptured)return;
 if(e.target===canvas){window.catExternalMouseDetected=true;if(typeof noteInput==='function')noteInput('kbm');}
 if(lockedMouse()){aim(e.movementX||0,e.movementY||0);return}''',
        'relative mouse look driver')
    return replace_once(s,'</script></body></html>',
        '</script><style id="cat-mouse-settings-hotfix">'+CSS+'</style><script id="cat-mouse-hotfix-js">'+JS+'</script></body></html>',
        'inject settings styling and keyboard controls')

def main():
    if len(sys.argv)!=2:
        print(__doc__);return 2
    source=Path(sys.argv[1]).expanduser().resolve()
    original=source.read_text(encoding='utf-8')
    patched=patch_html(original)
    targets=[ROOT/'game'/'index.html',ROOT/'android'/'app'/'src'/'main'/'assets'/'index.html']
    for target in targets:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(patched,encoding='utf-8')
        print(f'Created {target} ({target.stat().st_size:,} bytes)')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
