'use strict';
const { app, BrowserWindow } = require('electron');
const path = require('path');
let window;
function openGame() {
  window = new BrowserWindow({
    width: 1280, height: 720, minWidth: 800, minHeight: 450,
    backgroundColor: '#08090a', autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      backgroundThrottling: false,
      webSecurity: true
    }
  });
  window.setMenuBarVisibility(false);
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.loadFile(path.join(__dirname, 'game', 'index.html'));
}
app.whenReady().then(openGame);
app.on('window-all-closed', () => { app.quit(); });
