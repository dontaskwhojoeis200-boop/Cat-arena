package com.catarena.feralclaw;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    private GameView game;
    private boolean noticedMouse=false;
    private boolean captured=false;
    private boolean primaryButtonPressed=false;

    private void js(String code) { game.post(() -> game.evaluateJavascript(code, null)); }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        getWindow().setFlags(0x01000000,0x01000000); // hardware accelerated rendering
        game=new GameView();
        game.setFocusable(true);
        game.setFocusableInTouchMode(true);
        game.setWebChromeClient(new WebChromeClient());
        WebSettings settings=game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        game.addJavascriptInterface(new MouseBridge(),"AndroidBridge");
        setContentView(game);
        game.loadUrl("file:///android_asset/index.html");
        game.requestFocus();
    }
    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if(focus) immersive();
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if((event.getSource() & InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE && !noticedMouse) {
            noticedMouse=true;
            js("window.catExternalMouseDetected=true;if(typeof noteInput==='function')noteInput('kbm');");
        }
        return super.dispatchGenericMotionEvent(event);
    }
    @Override public void onBackPressed() {
        if(captured)game.releasePointerCapture();
        js("if(window.catBack)window.catBack();");
    }
    @Override protected void onDestroy() {
        game.destroy();
        super.onDestroy();
    }
    public final class MouseBridge {
        @JavascriptInterface public void requestMouseCapture(){
            game.post(() -> {
                if(Build.VERSION.SDK_INT>=26){game.requestFocus();game.requestPointerCapture();}
            });
        }
        @JavascriptInterface public void releaseMouseCapture(){
            game.post(() -> {
                if(Build.VERSION.SDK_INT>=26)game.releasePointerCapture();
            });
        }
    }
    private final class GameView extends WebView {
        GameView(){super(MainActivity.this);setBackgroundColor(0xff08090a);}
        @Override public void onPointerCaptureChange(boolean hasCapture) {
            super.onPointerCaptureChange(hasCapture);
            captured=hasCapture;
            if(!hasCapture)primaryButtonPressed=false;
            js("window.catNativeCaptureChanged&&window.catNativeCaptureChanged("+hasCapture+");");
        }
        @Override public boolean onCapturedPointerEvent(MotionEvent event) {
            switch(event.getActionMasked()) {
                case MotionEvent.ACTION_MOVE: {
                    float x=event.getAxisValue(MotionEvent.AXIS_RELATIVE_X);
                    float y=event.getAxisValue(MotionEvent.AXIS_RELATIVE_Y);
                    if(x==0f&&y==0f){x=event.getX();y=event.getY();}
                    if(Float.isFinite(x)&&Float.isFinite(y)&&(x!=0f||y!=0f))
                        js("window.catNativeMouseMove&&window.catNativeMouseMove("+x+","+y+");");
                    break;
                }
                case MotionEvent.ACTION_BUTTON_PRESS:
                case MotionEvent.ACTION_BUTTON_RELEASE:
                    break;
                default: break;
            }
            final boolean down=(event.getButtonState() & MotionEvent.BUTTON_PRIMARY)!=0;
            if(down!=primaryButtonPressed){
                primaryButtonPressed=down;
                js("window.catNativeMouseButton&&window.catNativeMouseButton("+down+");");
            }
            return true;
        }
    }
}
