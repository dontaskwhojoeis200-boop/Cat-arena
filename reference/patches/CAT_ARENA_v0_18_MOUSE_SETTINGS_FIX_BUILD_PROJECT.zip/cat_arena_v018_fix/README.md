# Cat Arena: Feral Claw v0.18 input and settings fix

This is a **source patch/build project**, NOT a finished APK or EXE. It requires the latest unmodified **v0.17 Cat Marine playable HTML** input. The ChatGPT Library copy could be inspected but was not available for binary extraction or rebuilding in this session. Do **not** distribute this project as if it were an installable game.

## What it fixes

- External hardware mouse on Android / DeX: detect mouse input and switch from touchscreen to keyboard-and-mouse controls, request native pointer capture using the Android WebView bridge, forward relative mouse deltas to the existing game `aim(dx,dy)` function.
- Desktop: keep regular HTML Pointer Lock; use its relative mouse deltas and don't interfere with visible game UI.
- Releasing capture when opening settings or pause; re-requesting capture on gameplay.
- Make all **six settings tabs** visible in a 3-by-2 grid (2-by-3 on narrow phones). Each settings pane scrolls independently with mouse wheel, touch, keyboard, or a scrollbar while its tab bar stays visible.
- Keyboard navigation: arrow keys when a settings tab is focused; Ctrl+Tab or Page Up/Down outside text inputs.

## Build prerequisites

1. Put the exact `CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html` game file in an `incoming/` folder next to `patch_game.py`. You can use the 18 MB `CatArena-FeralClaw-v0.17-Latest-Playable.html` file too, but rename it to the expected filename first.
2. Run `python patch_game.py incoming/CAT_ARENA_FERAL_CLAW_v0_17_CAT_MARINE_PLAYABLE.html`. The patch refuses mismatched versions rather than quietly corrupting a game.
3. Desktop: copy `game/index.html` to `desktop/game/index.html`, run `npm install && npm run dist:win` inside `desktop/` **on Windows**; resulting EXE in `desktop/dist/`.
4. Android: install Android SDK Platform 35, Java 17 and Gradle 8.10.2; run `gradle assembleDebug` inside `android/`; resulting installable debug-signed APK in `android/app/build/outputs/apk/debug/`.
5. Alternatively, push the project **with the original game HTML** to a GitHub repo and run **Actions > Build Cat Arena v0.18 APK and EXE > Run workflow**. The two jobs generate Windows and Android build artifacts.

This is a *best-effort, not device-tested* fix. Pointer capture behavior varies by Android device/WebView and must be tested on Android/DeX with a physical mouse. Android debug APKs use a debug signing certificate, so installing over an existing release-signed Cat Arena package may require uninstalling the old version first. **Back up your game data before uninstalling.**
