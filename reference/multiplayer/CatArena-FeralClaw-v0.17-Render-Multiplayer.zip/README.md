# Cat Arena Feral Claw | Render multiplayer relay

Runs the **v0.17 Cat Marine** browser game and four-player WebSocket multiplayer from Node.js 20+ on Render. Copy `game.html`, `server.js`, `package.json` and `render.yaml` to your Render-connected repository, preserving the paths. Set **Build Command** to `npm install`, **Start Command** to `npm start`, and **Health Check Path** to `/health`.

After deployment, check `https://YOUR-SERVICE.onrender.com/health`. It should return a JSON object with `"status":"ok"`. Start a multiplayer host from the Android APK or Windows EXE by entering `wss://YOUR-SERVICE.onrender.com/ws` in Multiplayer → Advanced. On another device, use the same WebSocket address, select the same map, and join the live server shown in the browser. If the host disconnects or Render restarts, hosted rooms close because this is a relay, **not** a dedicated authoritative game server.

The room discovery endpoint `/rooms` returns `version: 1`, build `VA-MODULAR-RB-011`, supported map IDs and live servers. The server checks build and map IDs when hosting/joining. A test harness verified create/room discovery/join/reject-mismatch/relay/health with mocked WebSocket connections. Live deployment and cross-device gameplay were **not** verified from this environment.

Run local test: `node tests/relay_smoke_test.js` from the release root (no installed ws dependency needed for the test). For a real server, run `npm install` first (requires network).
